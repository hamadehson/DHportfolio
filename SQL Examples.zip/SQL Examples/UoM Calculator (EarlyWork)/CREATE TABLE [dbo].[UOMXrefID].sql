
CREATE TABLE [dbo].[UOMXrefID](
	[ProdID] [int] NOT NULL,
	[PartID] [nvarchar](50) NOT NULL,
	[Std] [int] NOT NULL,
	[Alt] [int] NOT NULL
) ON [PRIMARY]
GO


