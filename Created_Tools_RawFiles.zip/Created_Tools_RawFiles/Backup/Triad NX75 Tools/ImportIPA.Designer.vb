﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImportIPA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.GetIPAListComboBoxBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ChieftainDataSet = New Triad_NX75_Tools.chieftainDataSet
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.GetListVehicleComboBoxBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ChieftainDataSet1 = New Triad_NX75_Tools.chieftainDataSet1
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Get_IPAList_ComboBoxTableAdapter = New Triad_NX75_Tools.chieftainDataSetTableAdapters.get_IPAList_ComboBoxTableAdapter
        Me.GetListVehicle_ComboBoxTableAdapter = New Triad_NX75_Tools.chieftainDataSet1TableAdapters.GetListVehicle_ComboBoxTableAdapter
        Me.Button4 = New System.Windows.Forms.Button
        CType(Me.GetIPAListComboBoxBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChieftainDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GetListVehicleComboBoxBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChieftainDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(31, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(439, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Select IPA Model File"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(205, 173)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Main Menu"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox1.Location = New System.Drawing.Point(31, 93)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(439, 20)
        Me.TextBox1.TabIndex = 2
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(124, 173)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Import IPA"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.GetIPAListComboBoxBindingSource
        Me.ComboBox1.DisplayMember = "Column1"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(31, 31)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(439, 21)
        Me.ComboBox1.TabIndex = 4
        Me.ComboBox1.ValueMember = "partid"
        '
        'GetIPAListComboBoxBindingSource
        '
        Me.GetIPAListComboBoxBindingSource.DataMember = "get_IPAList_ComboBox"
        Me.GetIPAListComboBoxBindingSource.DataSource = Me.ChieftainDataSet
        '
        'ChieftainDataSet
        '
        Me.ChieftainDataSet.DataSetName = "chieftainDataSet"
        Me.ChieftainDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ComboBox2
        '
        Me.ComboBox2.DataSource = Me.GetListVehicleComboBoxBindingSource
        Me.ComboBox2.DisplayMember = "VName"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(31, 136)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(439, 21)
        Me.ComboBox2.TabIndex = 5
        Me.ComboBox2.ValueMember = "VehicleId"
        '
        'GetListVehicleComboBoxBindingSource
        '
        Me.GetListVehicleComboBoxBindingSource.DataMember = "GetListVehicle_ComboBox"
        Me.GetListVehicleComboBoxBindingSource.DataSource = Me.ChieftainDataSet1
        '
        'ChieftainDataSet1
        '
        Me.ChieftainDataSet1.DataSetName = "chieftainDataSet1"
        Me.ChieftainDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(28, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(171, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Select IPA To Replace"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(160, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(161, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Leave blank to import a new IPA"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Select Vehicle To Update"
        '
        'Get_IPAList_ComboBoxTableAdapter
        '
        Me.Get_IPAList_ComboBoxTableAdapter.ClearBeforeFill = True
        '
        'GetListVehicle_ComboBoxTableAdapter
        '
        Me.GetListVehicle_ComboBoxTableAdapter.ClearBeforeFill = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(286, 173)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Reset Form"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ImportIPA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(482, 276)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "ImportIPA"
        Me.Text = "ImportIPA"
        CType(Me.GetIPAListComboBoxBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChieftainDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GetListVehicleComboBoxBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChieftainDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ChieftainDataSet As Triad_NX75_Tools.chieftainDataSet
    Friend WithEvents GetIPAListComboBoxBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Get_IPAList_ComboBoxTableAdapter As Triad_NX75_Tools.chieftainDataSetTableAdapters.get_IPAList_ComboBoxTableAdapter
    Friend WithEvents ChieftainDataSet1 As Triad_NX75_Tools.chieftainDataSet1
    Friend WithEvents GetListVehicleComboBoxBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GetListVehicle_ComboBoxTableAdapter As Triad_NX75_Tools.chieftainDataSet1TableAdapters.GetListVehicle_ComboBoxTableAdapter
    Friend WithEvents Button4 As System.Windows.Forms.Button
End Class
