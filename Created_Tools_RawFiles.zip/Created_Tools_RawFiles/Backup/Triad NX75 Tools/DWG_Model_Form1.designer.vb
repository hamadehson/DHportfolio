<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DWG_Model_Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DWG_Model_Form1))
        Me.btnDirectory = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.btnProcess = New System.Windows.Forms.Button
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.BtnFile = New System.Windows.Forms.Button
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.btnQuit = New System.Windows.Forms.Button
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.chkSubDir = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'btnDirectory
        '
        Me.btnDirectory.Location = New System.Drawing.Point(30, 12)
        Me.btnDirectory.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDirectory.Name = "btnDirectory"
        Me.btnDirectory.Size = New System.Drawing.Size(392, 28)
        Me.btnDirectory.TabIndex = 0
        Me.btnDirectory.Text = "Select Directory to List"
        Me.btnDirectory.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(30, 44)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(393, 20)
        Me.TextBox1.TabIndex = 1
        '
        'btnProcess
        '
        Me.btnProcess.Location = New System.Drawing.Point(30, 227)
        Me.btnProcess.Margin = New System.Windows.Forms.Padding(2)
        Me.btnProcess.Name = "btnProcess"
        Me.btnProcess.Size = New System.Drawing.Size(62, 23)
        Me.btnProcess.TabIndex = 3
        Me.btnProcess.Text = "Start"
        Me.btnProcess.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(30, 193)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(2)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(392, 19)
        Me.ProgressBar1.Step = 1
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBar1.TabIndex = 5
        Me.ProgressBar1.Visible = False
        '
        'BtnFile
        '
        Me.BtnFile.Location = New System.Drawing.Point(30, 78)
        Me.BtnFile.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnFile.Name = "BtnFile"
        Me.BtnFile.Size = New System.Drawing.Size(392, 27)
        Me.BtnFile.TabIndex = 6
        Me.BtnFile.Text = "Select Location & Name for Output File"
        Me.BtnFile.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(30, 109)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(393, 20)
        Me.TextBox3.TabIndex = 7
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Location = New System.Drawing.Point(120, 227)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(62, 23)
        Me.btnQuit.TabIndex = 8
        Me.btnQuit.Text = "Main Menu"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(154, 171)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(120, 20)
        Me.TextBox2.TabIndex = 11
        '
        'chkSubDir
        '
        Me.chkSubDir.AutoSize = True
        Me.chkSubDir.Location = New System.Drawing.Point(447, 23)
        Me.chkSubDir.Name = "chkSubDir"
        Me.chkSubDir.Size = New System.Drawing.Size(134, 17)
        Me.chkSubDir.TabIndex = 12
        Me.chkSubDir.Text = "Inculde Sub-directories"
        Me.chkSubDir.UseVisualStyleBackColor = True
        '
        'DWG_Model_Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(593, 284)
        Me.Controls.Add(Me.chkSubDir)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.BtnFile)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.btnProcess)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnDirectory)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "DWG_Model_Form1"
        Me.Text = "Get Level 2 Items"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDirectory As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents btnProcess As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents BtnFile As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents chkSubDir As System.Windows.Forms.CheckBox

End Class
