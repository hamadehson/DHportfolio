Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies
Imports System.Windows.Forms

Public Class Warning_Note_Form1
    Dim drs As String()
    Dim cntr As Integer

    Private Sub Warning_Note_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click
        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        validate_Data()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFile.Click
        TextBox3.Text = Get_Directory()
        'TextBox3.Text = Get_file_Name_Save("Text Files (*.txt)|*.txt|All (*.*)|*.*")
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Sub validate_Data()

        Dim getsubs As Integer
        getsubs = CheckBox1.Checked
        getsubs = Math.Abs(getsubs)

        cntr = 0

        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a Source Directory.")
            btnDirectory.Focus()
            Exit Sub
        End If

        If TextBox3.Text Is Nothing Or TextBox3.Text = "" Then
            MsgBox("Please select a Target Directory.")
            BtnFile.Focus()
            Exit Sub
        End If
        Dim ss As String
        ss = txtFilter.Text



        'drs = Directory.GetFiles(TextBox1.Text, "*.prt", getsubs)
        drs = Directory.GetFiles(TextBox1.Text, txtFilter.Text, getsubs)

        'get number of files in the dir
        cntr = drs.Length



        'display the number of files in the dir and selected attributes
        Dim t As String
        t = "You have selected """ & TextBox1.Text & """ as the directory to process (Source)." & vbCrLf _
        & "This directory contains " & cntr & " files.  Filtered by " & txtFilter.Text & vbCrLf _
        & "The updated drawing files will be written to """ & TextBox3.Text & " (Target).""" & vbCrLf & vbCrLf _
        & "Do you want to continue?"

        If MsgBox(t, MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        ProgressBar1.Maximum = cntr
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        updateDWGFile()
        'Get_File_list()
        Cursor = Cursors.Arrow
        MsgBox("done")
    End Sub

   
    Private Sub updateDWGFile()
        Dim file As String
        cntr = 0

        Dim theSession As Session = Session.GetSession()
        Dim basePart1 As BasePart
        Dim partLoadStatus1 As PartLoadStatus


        'enter the data into the list
        For Each file In drs

            If Not System.IO.File.Exists(TextBox3.Text & "\" & Path.GetFileName(file)) Then

                Try

                    '' ----------------------------------------------
                    ''   Menu: File->Open...
                    '' ----------------------------------------------
                    basePart1 = theSession.Parts.OpenBaseDisplay(file, partLoadStatus1)
                    Dim workPart As Part = theSession.Parts.Work
                    Dim displayPart As Part = theSession.Parts.Display
                    Dim dwgs As Drawings.DrawingSheetCollection
                    Dim sheet As Drawings.DrawingSheet
                    Dim sheets1() As NXObject

                    partLoadStatus1.Dispose()

                    dwgs = workPart.DrawingSheets
                    sheets1 = dwgs.ToArray()

                    sheet = CType(workPart.DrawingSheets.FindObject(sheets1(0).Name), Drawings.DrawingSheet)

                    sheet.Open()

                    Dim markId1 As Session.UndoMarkId
                    markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

                    'Dim markId2 As Session.UndoMarkId
                    'markId2 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Add Base View")

                    ' ----------------------------------------------
                    '   Menu: Insert->Text...
                    ' ----------------------------------------------
                    Dim markId3 As Session.UndoMarkId
                    markId3 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Create Annotation")

                    Dim letteringPreferences1 As Annotations.LetteringPreferences
                    letteringPreferences1 = workPart.Annotations.Preferences.GetLetteringPreferences()

                    Dim userSymbolPreferences1 As Annotations.UserSymbolPreferences
                    userSymbolPreferences1 = workPart.Annotations.NewUserSymbolPreferences(Annotations.UserSymbolPreferences.SizeType.ScaleAspectRatio, 1.0, 1.0)

                    Dim textLines1(0) As String
                    textLines1(0) = ""
                    Dim origin1 As Point3d = New Point3d(0.0, 0.0, 0.0)
                    Dim note1 As Annotations.Note
                    note1 = workPart.Annotations.CreateNote(textLines1, origin1, AxisOrientation.Horizontal, letteringPreferences1, userSymbolPreferences1)

                    letteringPreferences1.AlignmentPosition = Annotations.AlignmentPosition.BottomLeft
                    note1.SetLetteringPreferences(letteringPreferences1)
                    note1.LeaderOrientation = Annotations.LeaderOrientation.FromLeft

                    theSession.SetUndoMarkVisibility(markId3, "Create Annotation", Session.MarkVisibility.Visible)

                    Dim lines1(4) As String
                    lines1(0) = "WARNING: THIS DOCUMENT CONTAINS TECHNICAL DATA WHOSE EXPORT"
                    lines1(1) = "IS RESTRICTED BY THE ARMS EXPORT CONTROL ACT TITLE 22 USC"
                    lines1(2) = "SEC. 2751 ET SEQ., OR THE EXPORT ADMINISTRATION ACT OF 1979,"
                    lines1(3) = "AS AMENDED, TITLE 50 USC APP 2401 ET SEQ. VIOLATIONS OF THESE"
                    lines1(4) = "EXPORT LAWS ARE SUBJECT TO SEVERE CRIMINAL PENALTIES."
                    note1.SetText(lines1)

                    'Dim origin2 As Point3d = New Point3d(95, 20, 0.0)
                    Dim origin2 As Point3d = New Point3d(65, 15, 0.0)
                    note1.AnnotationOrigin = origin2

                    Dim nErrs1 As Integer
                    nErrs1 = theSession.UpdateManager.DoUpdate(markId3)

                    Dim markId4 As Session.UndoMarkId
                    markId4 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Create Annotation")

                    letteringPreferences1.Dispose()
                    userSymbolPreferences1.Dispose()


                    ' ----------------------------------------------
                    '   Menu: File->Save As...
                    ' ----------------------------------------------

                    Dim partSaveStatus1 As PartSaveStatus
                    partSaveStatus1 = workPart.SaveAs(TextBox3.Text & "\" & Path.GetFileName(file))

                    partSaveStatus1.Dispose()

                    ' ----------------------------------------------
                    '   Menu: File->Close->All Parts
                    ' ----------------------------------------------
                    theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)

                    workPart = Nothing
                    displayPart = Nothing
                    ' ----------------------------------------------
                    '   Menu: Tools->Journal->Stop
                    ' ----------------------------------------------
                Catch

                    FileOpen(2, TextBox3.Text & "\err.log", OpenMode.Output)
                    PrintLine(2, file)
                    FileClose(2)

                End Try
            End If
            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum
            Me.Refresh()
            Application.DoEvents()

        Next
     
    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged

        txtFilter.Text = "*dwg*.prt"

        If CheckBox2.Checked Then
            txtFilter.Visible = True
            Label1.Visible = True
        Else
            txtFilter.Visible = False
            Label1.Visible = False

        End If
    End Sub
End Class