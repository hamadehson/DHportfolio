﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenu))
        Me.btnGMAttributes = New System.Windows.Forms.Button
        Me.btnDwgModel = New System.Windows.Forms.Button
        Me.btnCreatePDF = New System.Windows.Forms.Button
        Me.btnCreateXT = New System.Windows.Forms.Button
        Me.btnQuit = New System.Windows.Forms.Button
        Me.btnSTEP = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnWarningNote = New System.Windows.Forms.Button
        Me.btnClearAttributes = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.IPAImport = New System.Windows.Forms.Button
        Me.btnCopyFiles = New System.Windows.Forms.Button
        Me.btnBMP = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnGMAttributes
        '
        Me.btnGMAttributes.Location = New System.Drawing.Point(12, 30)
        Me.btnGMAttributes.Name = "btnGMAttributes"
        Me.btnGMAttributes.Size = New System.Drawing.Size(235, 29)
        Me.btnGMAttributes.TabIndex = 0
        Me.btnGMAttributes.Text = "Get GM Attributes from File"
        Me.btnGMAttributes.UseVisualStyleBackColor = True
        '
        'btnDwgModel
        '
        Me.btnDwgModel.Location = New System.Drawing.Point(12, 65)
        Me.btnDwgModel.Name = "btnDwgModel"
        Me.btnDwgModel.Size = New System.Drawing.Size(235, 29)
        Me.btnDwgModel.TabIndex = 1
        Me.btnDwgModel.Text = "Get Parent of Assembly or Drawing File"
        Me.btnDwgModel.UseVisualStyleBackColor = True
        '
        'btnCreatePDF
        '
        Me.btnCreatePDF.Location = New System.Drawing.Point(12, 100)
        Me.btnCreatePDF.Name = "btnCreatePDF"
        Me.btnCreatePDF.Size = New System.Drawing.Size(235, 29)
        Me.btnCreatePDF.TabIndex = 2
        Me.btnCreatePDF.Text = "Create PDF for Drawing Files"
        Me.btnCreatePDF.UseVisualStyleBackColor = True
        '
        'btnCreateXT
        '
        Me.btnCreateXT.Location = New System.Drawing.Point(12, 412)
        Me.btnCreateXT.Name = "btnCreateXT"
        Me.btnCreateXT.Size = New System.Drawing.Size(235, 29)
        Me.btnCreateXT.TabIndex = 3
        Me.btnCreateXT.Text = "Export to Parasolid"
        Me.btnCreateXT.UseVisualStyleBackColor = True
        Me.btnCreateXT.Visible = False
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(157, 579)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(90, 29)
        Me.btnQuit.TabIndex = 4
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnSTEP
        '
        Me.btnSTEP.Location = New System.Drawing.Point(12, 135)
        Me.btnSTEP.Name = "btnSTEP"
        Me.btnSTEP.Size = New System.Drawing.Size(235, 29)
        Me.btnSTEP.TabIndex = 5
        Me.btnSTEP.Text = "Export to STEP214"
        Me.btnSTEP.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 579)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 29)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "About"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnWarningNote
        '
        Me.btnWarningNote.Location = New System.Drawing.Point(12, 170)
        Me.btnWarningNote.Name = "btnWarningNote"
        Me.btnWarningNote.Size = New System.Drawing.Size(235, 29)
        Me.btnWarningNote.TabIndex = 7
        Me.btnWarningNote.Text = "Export Warning Note"
        Me.btnWarningNote.UseVisualStyleBackColor = True
        '
        'btnClearAttributes
        '
        Me.btnClearAttributes.Location = New System.Drawing.Point(12, 205)
        Me.btnClearAttributes.Name = "btnClearAttributes"
        Me.btnClearAttributes.Size = New System.Drawing.Size(235, 29)
        Me.btnClearAttributes.TabIndex = 8
        Me.btnClearAttributes.Text = "Clear File Attributes"
        Me.btnClearAttributes.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 240)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(235, 29)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Get Chieftain Attributes from File"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(12, 275)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(235, 29)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Find Copies"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'IPAImport
        '
        Me.IPAImport.Location = New System.Drawing.Point(12, 310)
        Me.IPAImport.Name = "IPAImport"
        Me.IPAImport.Size = New System.Drawing.Size(235, 29)
        Me.IPAImport.TabIndex = 11
        Me.IPAImport.Text = "Import IPA Model File"
        Me.IPAImport.UseVisualStyleBackColor = True
        '
        'btnCopyFiles
        '
        Me.btnCopyFiles.Location = New System.Drawing.Point(12, 345)
        Me.btnCopyFiles.Name = "btnCopyFiles"
        Me.btnCopyFiles.Size = New System.Drawing.Size(235, 26)
        Me.btnCopyFiles.TabIndex = 12
        Me.btnCopyFiles.Text = "Copy FIle List to New Location"
        Me.btnCopyFiles.UseVisualStyleBackColor = True
        '
        'btnBMP
        '
        Me.btnBMP.Location = New System.Drawing.Point(12, 447)
        Me.btnBMP.Name = "btnBMP"
        Me.btnBMP.Size = New System.Drawing.Size(235, 29)
        Me.btnBMP.TabIndex = 13
        Me.btnBMP.Text = "Create File Preview Bitmap"
        Me.btnBMP.UseVisualStyleBackColor = True
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(273, 646)
        Me.Controls.Add(Me.btnBMP)
        Me.Controls.Add(Me.btnCopyFiles)
        Me.Controls.Add(Me.IPAImport)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnClearAttributes)
        Me.Controls.Add(Me.btnWarningNote)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnSTEP)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnCreateXT)
        Me.Controls.Add(Me.btnCreatePDF)
        Me.Controls.Add(Me.btnDwgModel)
        Me.Controls.Add(Me.btnGMAttributes)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MainMenu"
        Me.Text = "Triad NX75 Tools - Main Menu"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnGMAttributes As System.Windows.Forms.Button
    Friend WithEvents btnDwgModel As System.Windows.Forms.Button
    Friend WithEvents btnCreatePDF As System.Windows.Forms.Button
    Friend WithEvents btnCreateXT As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents btnSTEP As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnWarningNote As System.Windows.Forms.Button
    Friend WithEvents btnClearAttributes As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents IPAImport As System.Windows.Forms.Button
    Friend WithEvents btnCopyFiles As System.Windows.Forms.Button
    Friend WithEvents btnBMP As System.Windows.Forms.Button
End Class
