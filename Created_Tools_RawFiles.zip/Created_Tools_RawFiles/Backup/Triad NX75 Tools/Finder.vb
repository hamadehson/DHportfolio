﻿Imports System.IO

Public Class Finder
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

       
        If validateEntry() Then
            lockButtons(True)
            checkFiles(TextBox1.Text)
            Button4.Visible = True
            MsgBox("Done")
            lockButtons(False)
        End If

    End Sub
    

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        FolderBrowserDialog1.ShowDialog()

        If FolderBrowserDialog1.SelectedPath = "" Then
            MsgBox("Please select a Source Directory")
            Button2.Focus()
            Exit Sub
        Else
            TextBox1.Text = FolderBrowserDialog1.SelectedPath

        End If
    End Sub


    Private Sub checkFiles(ByVal sourceDirectory As String)

        Dim sDir As String()
        Dim fName2 As String


        ProgressBar1.Value = 0
        CheckedListBox1.Items.Clear()
        sDir = Directory.GetFiles(sourceDirectory)
        ProgressBar1.Maximum = sDir.Length
        TextBox5.Text = "0 of " & sDir.Length

        Cursor = Cursors.WaitCursor

        For Each fName As String In sDir
            fName2 = Path.GetFileName(fName)
            If LCase(fName2) <> "thumbs.db" Then
                TextBox2.Text = fName2
                ProgressBar1.Increment(1)
                TextBox5.Text = ProgressBar1.Value & " of " & sDir.Length
                Application.DoEvents()


                Dim i As Integer
                For i = 0 To ListBox1.Items.Count - 1
                    checkDirectories(fName2, ListBox1.Items(i))
                Next
            End If
        Next

        TextBox2.Text = "Done"
        ProgressBar1.Increment(1)
        TextBox5.Text = ProgressBar1.Value & " of " & sDir.Length
        Application.DoEvents()
        Cursor = Cursors.Arrow
    End Sub

    Private Sub checkDirectories(ByVal fName As String, ByVal searchDirectory As String)

        Dim fileNameAndPath As String = ""
        Dim xFile As String = ""
        Dim di As New DirectoryInfo(searchDirectory)

        TextBox4.Text = di.FullName
        'Me.Refresh()

        For Each fi As FileInfo In di.GetFiles()
            fileNameAndPath = fi.FullName
            xFile = Path.GetFileName(fileNameAndPath)
            If Not xFile Is Nothing Then
                If xFile.Length > 0 Then
                    If xFile = fName Then
                        CheckedListBox1.Items.Add(fileNameAndPath)

                    End If
                End If
            End If
            Application.DoEvents()
        Next
        For Each dir As DirectoryInfo In di.GetDirectories()
            If dir.FullName <> TextBox1.Text Then
                checkDirectories(fName, dir.FullName)
            End If
        Next

    End Sub

    Private Function validateEntry() As Boolean

        validateEntry = False

        If TextBox1.Text = "" Then
            MsgBox("Please select a Source Directory")
            Button2.Focus()
            Exit Function
        End If

        If Not Directory.Exists(TextBox1.Text) Then
            MsgBox("The Source Directory you entered does not exist, please re-enter or select the Source Directory")
            Button2.Focus()
            Exit Function
        End If

        If ListBox1.Items.Count = 0 Then
            MsgBox("Please select a Search Directory")
            Button9.Focus()
            Exit Function
        End If

        validateEntry = True
    End Function

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Cursor = Cursors.WaitCursor

        Dim i As Integer

        For i = 0 To CheckedListBox1.CheckedItems.Count - 1
            Kill(CheckedListBox1.CheckedItems(i))


        Next i

        While CheckedListBox1.CheckedItems.Count > 0
            CheckedListBox1.Items.Remove(CheckedListBox1.CheckedItems(0))
        End While
       
        CheckedListBox1.Refresh()

        Cursor = Cursors.Arrow
    End Sub

    Private Sub lockButtons(ByVal bset As Boolean)
        Button1.Enabled = Not bset
        Button2.Enabled = Not bset

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        lockButtons(False)
        Button4.Visible = False
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ProgressBar1.Value = 0
        CheckedListBox1.Items.Clear()


    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

        Dim i As Integer
        For i = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemChecked(i, True)
        Next


    End Sub


    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim i As Integer
        For i = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemChecked(i, False)
        Next


    End Sub

   
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click

        FolderBrowserDialog1.ShowDialog()

        Dim r As IO.StreamReader
        r = New IO.StreamReader(TextBox6.Text)
        'While (r.Peek() > -1)
        While r.EndOfStream <> True
            If r.ReadLine = FolderBrowserDialog1.SelectedPath Then
                MsgBox("The item you selected already exists in the list.")
                Exit Sub
            End If
        End While
        r.Close()

        FileOpen(1, TextBox6.Text, OpenMode.Append)
        PrintLine(1, FolderBrowserDialog1.SelectedPath)
        FileClose(1)

        ListBox1.Items.Clear()
        loadList()

    End Sub

   
    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        TextBox6.Visible = Not TextBox6.Visible
    End Sub

    Private Sub Finder_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       
        loadList()

    End Sub

    Private Sub loadList()
        Dim r As IO.StreamReader
        r = New IO.StreamReader(TextBox6.Text)
        While r.EndOfStream <> True
            ListBox1.Items.Add(r.ReadLine)
        End While
        r.Close()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
       
        ListBox1.Items.Remove(ListBox1.SelectedItem)

        FileOpen(1, TextBox6.Text, OpenMode.Output)


        Dim i As Integer
        For i = 0 To ListBox1.Items.Count - 1
            PrintLine(1, ListBox1.Items(i))
        Next
        FileClose(1)
        ListBox1.Items.Clear()
        loadList()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        gotomain(Me)
    End Sub

    Private Sub Finder_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        gotomain(Me)
    End Sub
End Class