Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies


Public Class DWG_Model_Form1
    Dim drs As String()
    Private Sub DWG_Model_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click
        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        validate_Data()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFile.Click
        TextBox3.Text = Get_file_Name_Save("Text Files (*.txt)|*.txt|All (*.*)|*.*")
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Sub validate_Data()
        Dim filecnt As Integer
        Dim subdir As Integer
        subdir = chkSubDir.Checked
        subdir = Math.Abs(subdir)

        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a directory.")
            btnDirectory.Focus()
            Exit Sub
        End If

        If TextBox3.Text Is Nothing Or TextBox3.Text = "" Then
            MsgBox("Please select a file.")
            BtnFile.Focus()
            Exit Sub
        End If


        ' get list of files in the dir
        drs = Directory.GetFiles(TextBox1.Text, "*.prt", subdir)


        'count the number of files in the dir
        filecnt = drs.Length

        'display the number of files in the dir and selected attributes
        Dim t As String
        t = "You have selected """ & TextBox1.Text & """ as the directory to process." & vbCrLf _
        & "This directory contains " & filecnt & " .prt files." & vbCrLf _
        & "The text file for the list will be written to """ & TextBox3.Text & ".""" & vbCrLf & vbCrLf _
        & "Do you want to continue?"

        If MsgBox(t, MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        ProgressBar1.Maximum = filecnt
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        Get_File_list()
        Cursor = Cursors.Arrow
        MsgBox("done")
    End Sub
   
   
    Private Sub Get_File_list()
        Dim cntr As Integer
        Dim file As String

        ' --- Open file for text output
        FileOpen(1, TextBox3.Text, OpenMode.Output)

        'enter the data into the list
        For Each file In drs
            Dim theSession As Session = Session.GetSession()
            ' ----------------------------------------------
            '   Menu: File->Options->Assembly Load Options...
            ' ----------------------------------------------
            Dim markId1 As Session.UndoMarkId
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start")

            theSession.SetUndoMarkName(markId1, "Assembly Load Options")

            Dim markId2 As Session.UndoMarkId
            markId2 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Assembly Load Options")

            theSession.Parts.LoadOptions.LoadLatest = False

            theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.AsSaved

            theSession.Parts.LoadOptions.ComponentsToLoad = LoadOptions.LoadComponents.None

            theSession.Parts.LoadOptions.UsePartialLoading = True

            theSession.Parts.LoadOptions.SetInterpartData(False, LoadOptions.Parent.Partial)

            theSession.Parts.LoadOptions.AbortOnFailure = False

            theSession.Parts.LoadOptions.AllowSubstitution = False

            theSession.Parts.LoadOptions.GenerateMissingPartFamilyMembers = True

            theSession.Parts.LoadOptions.ReferenceSetOverride = False

            Dim referenceSets1(4) As String
            referenceSets1(0) = "As Saved"
            referenceSets1(1) = "Entire Part"
            referenceSets1(2) = "Empty"
            referenceSets1(3) = "Use Lightweight"
            referenceSets1(4) = "Use Model"
            theSession.Parts.LoadOptions.SetDefaultReferenceSets(referenceSets1)

            Dim searchDirectories1(0) As String
            searchDirectories1(0) = "C:\Program Files\UGS\NX 7.5\UGII"
            Dim searchSubDirs1(0) As Boolean
            searchSubDirs1(0) = True
            theSession.Parts.LoadOptions.SetSearchDirectories(searchDirectories1, searchSubDirs1)

            theSession.DeleteUndoMark(markId2, Nothing)

            ' ----------------------------------------------
            '   Menu: File->Open...
            ' ----------------------------------------------

            Dim basePart1 As BasePart
            Dim partLoadStatus1 As PartLoadStatus
            basePart1 = theSession.Parts.OpenBaseDisplay(file, partLoadStatus1)

            Dim workPart As Part = theSession.Parts.Work

            Dim s As String
            s = workPart.Leaf
            Dim ss As String

            Dim comp As ComponentAssembly = workPart.ComponentAssembly
            If comp Is Nothing Then
                ss = s & ";No Child"
                PrintLine(1, ss)
            Else
                If comp.RootComponent Is Nothing Then
                    ss = s & ";No Child"
                    PrintLine(1, ss)
                Else
                    Dim children As Component() = comp.RootComponent.GetChildren()
                    Dim child As Component
                    For Each child In children


                        ss = s & ";" & child.Name
                        PrintLine(1, ss)
                    Next
                End If
            End If

            partLoadStatus1.Dispose()
            Dim markId3 As Session.UndoMarkId
            markId3 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

            Dim markId4 As Session.UndoMarkId
            markId4 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

            ' ----------------------------------------------
            '   Menu: File->Close->All Parts
            ' ----------------------------------------------
            theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)

            workPart = Nothing

            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum

        Next
        'close the text file
        FileClose(1)

    End Sub
End Class