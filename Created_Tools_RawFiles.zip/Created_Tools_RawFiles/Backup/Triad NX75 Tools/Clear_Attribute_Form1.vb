Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies
Imports System.Windows.Forms
Imports mvs = Microsoft.VisualBasic.Strings
Imports System.Data.SqlClient

Public Class Clear_Attribute_Form1
    Dim drs As String()
    Dim cntr As Integer
    'Dim fileCount As String()


    Private Sub Clear_Attribute_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
        Attributes_Load()
        btnUnselAll_Click()
        RadioButton1.Checked = True

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click
        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        If Not validate_Data() Then
            Exit Sub
        End If

        btnProcess.Enabled = False
        btnQuit.Enabled = False



        ProgressBar1.Maximum = cntr
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        TextBox2.Text = "0 of " & ProgressBar1.Maximum
        Me.Refresh()



        updateFiles()
        Cursor = Cursors.Arrow
        MsgBox("done")

        btnProcess.Enabled = True
        btnQuit.Enabled = True
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Function validate_Data() As Boolean
        validate_Data = False

        Dim getsubs As Integer
        getsubs = (CheckBox1.Checked)
        getsubs = Math.Abs(getsubs)

        cntr = 0
        'ReDim fileCount(cntr)

        ' make sure a directory was selected
        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a directory.", , "Directory Check")
            btnDirectory.Focus()
            Exit Function
        End If

        'make sure as filter is entered
        If txtFilter.Text Is Nothing Or txtFilter.Text = "" Then
            MsgBox("Please enter a filter string or unselect the ""Use custom Filter Box""", , "Filter Check")
            txtFilter.Focus()
            Exit Function
        End If



        ' make sure a check box was selected
        If CheckedListBox1.SelectedIndex = -1 Then
            MsgBox("At least one item must be selected", , "Select Item")
            Exit Function
        End If


        ' get list of files in the dir
        drs = Directory.GetFiles(TextBox1.Text, txtFilter.Text, getsubs)

        cntr = drs.Length.ToString()

        If cntr = 0 Then
            MsgBox("There are no files in the directory that meet the filter requirement.", , "File Check")
            Exit Function

        Else
            'display the number of files in the dir and selected attributes
            Dim t As String
            t = "You have selected """ & TextBox1.Text & """ as the directory to process." & vbCrLf _
            & "This directory contains " & cntr & " " & txtFilter.Text & " files." & vbCrLf _
                   & "Do you want to continue?"

            If MsgBox(t, MsgBoxStyle.YesNo, "File Check") = MsgBoxResult.No Then
                validate_Data = False
                Exit Function
            End If
        End If
        validate_Data = True


    End Function

    Private Sub updateFiles()

        cntr = 0

        'enter the data into the list
        For Each fileName In drs

            TextBox3.Text = fileName
            Me.Refresh()
            modifyAttributes(fileName)

            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum
            Me.Refresh()
            Application.DoEvents()
        Next


    End Sub



    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            txtFilter.Visible = True
        Else
            txtFilter.Visible = False
        End If

        txtFilter.Text = "*.prt"
    End Sub



    Private Sub Attributes_Load()
        Dim sqlConn As New SqlConnection
        sqlConn.ConnectionString = "Data Source=databasesvr1;Initial Catalog=TriadSecurity;Integrated Security=True;Persist Security Info=True;User ID=jrush;Password=jrush22"
        Dim cmd As New SqlCommand
        Dim ds As SqlDataReader
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "GetAttributesToUpdate"
        cmd.Connection = sqlConn
        cmd.Parameters.AddWithValue("@ProjectId", 25)
        If sqlConn.State = ConnectionState.Closed Then
            sqlConn.Open()
        End If
        ds = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        Do While ds.Read()
            CheckedListBox1.Items.Add(ds.GetValue(0), True)
        Loop
        ds.Close()

    End Sub

    Private Sub btnSelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelAll.Click
        Dim i As Integer

        For i = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemChecked(i, True)
        Next

    End Sub

    Private Sub btnUnselAll_Click() Handles btnUnselAll.Click
        Dim i As Integer

        For i = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemChecked(i, False)
        Next
    End Sub
    Private Sub modifyAttributes(ByVal fileName As String)

        Dim theSession As Session = Session.GetSession()
        Dim basePart1 As BasePart
        Dim partLoadStatus1 As PartLoadStatus

        On Error Resume Next

        theSession.Parts.LoadOptions.LoadLatest = False
        theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.FromDirectory
        theSession.Parts.LoadOptions.ComponentsToLoad = LoadOptions.LoadComponents.None
        theSession.Parts.LoadOptions.UsePartialLoading = True
        theSession.Parts.LoadOptions.SetInterpartData(False, LoadOptions.Parent.Partial)
        theSession.Parts.LoadOptions.AbortOnFailure = False
        theSession.Parts.LoadOptions.AllowSubstitution = False
        theSession.Parts.LoadOptions.GenerateMissingPartFamilyMembers = True
        theSession.Parts.LoadOptions.ReferenceSetOverride = False

        basePart1 = theSession.Parts.OpenBaseDisplay(fileName, partLoadStatus1)

        Dim workPart As Part = theSession.Parts.Work

      
        partLoadStatus1.Dispose()

        Dim i As Integer
        'On Error Resume Next
        For i = 0 To CheckedListBox1.CheckedItems.Count - 1
            If RadioButton1.Checked Then
                workPart.SetAttribute(CheckedListBox1.CheckedItems(i), "")
            Else
                workPart.DeleteAttributeByTypeAndTitle(NXObject.AttributeType.String, CheckedListBox1.CheckedItems(i))
            End If
        Next i
        'On Error GoTo 0

   
        Dim partSaveStatus1 As PartSaveStatus
        partSaveStatus1 = workPart.Save(BasePart.SaveComponents.False, BasePart.CloseAfterSave.True)

        partSaveStatus1.Dispose()
       
        workPart = Nothing
        basePart1 = Nothing
        theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)
        theSession = Nothing
        Application.DoEvents()
        On Error GoTo 0
    End Sub
    
End Class
    
