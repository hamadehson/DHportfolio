﻿Option Strict Off
Imports mvs = Microsoft.VisualBasic.Strings
Imports System.IO
Imports NXOpen
Imports NXOpen.Assemblies
Imports System.Data.SqlClient
Imports System.Configuration
Imports NXOpen.Session

Public Class ImportIPA
    Private cmd As New SqlCommand
    Private sqlConn As New SqlConnection
    Private fName As String

    Private Sub ImportIPA_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        If sqlConn.State = ConnectionState.Open Then
            sqlConn.Close()
        End If

        gotomain(Me)
    End Sub

    Private Sub ImportIPA_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'TODO: This line of code loads data into the 'ChieftainDataSet1.GetListVehicle_ComboBox' table. You can move, or remove it, as needed.
        Me.GetListVehicle_ComboBoxTableAdapter.Fill(Me.ChieftainDataSet1.GetListVehicle_ComboBox)
        'TODO: This line of code loads data into the 'ChieftainDataSet.get_IPAList_ComboBox' table. You can move, or remove it, as needed.
        Me.Get_IPAList_ComboBoxTableAdapter.Fill(Me.ChieftainDataSet.get_IPAList_ComboBox)

        sqlConn.ConnectionString = "Data Source=Databasesvr1;Initial Catalog=Chieftain;Integrated Security=True;Persist Security Info=True;User ID=jrush;Password=jrush22"
        cmd.Connection = sqlConn
        cmd.CommandType = CommandType.Text
        If sqlConn.State = ConnectionState.Closed Then
            sqlConn.Open()
        End If
        Button1.Text = "Select IPA File to Import"

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        TextBox1.Text = Get_file_Name_Open("part (*.prt)|*.prt|All (*.*)|*.*", "T:\")
        fName = System.IO.Path.GetFileNameWithoutExtension(TextBox1.Text)

    End Sub
   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        If sqlConn.State = ConnectionState.Open Then
            sqlConn.Close()
        End If

        gotomain(Me)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click


        If ComboBox1.SelectedValue = 0 Then
            If MsgBox("You have select ""None"" of the IPA to replace. Do you with to continue?", MsgBoxStyle.YesNo, "Confirm Selection") = MsgBoxResult.No Then
                ComboBox1.Focus()
                Exit Sub
            End If
        End If


        If TextBox1.Text = "" Then
            MsgBox("Please select a directory for import.")
            Button1.Focus()
            Exit Sub
        End If

        If ComboBox2.SelectedValue = 0 Then
            MsgBox("Please select a Vehicle to update.", MsgBoxStyle.Exclamation, "Confirm Selection")
            ComboBox2.Focus()
            Exit Sub
        End If

        Me.Cursor = Cursors.WaitCursor


        ClearTable()
        Get_File_list(TextBox1.Text)
        Update_IPA_List(TextBox1.Text)
        ClearTable()

        Me.Cursor = Cursors.Default
        MsgBox("Done")
        Button2.Focus()
        Button3.Enabled = False

    End Sub
    Private Sub ClearTable()
        cmd.CommandText = "Delete from IPAImport"
        cmd.ExecuteNonQuery()

    End Sub
    Private Sub Get_File_list(filename As String)
        'Dim cntr As Integer
        'Dim file As String


        Dim theSession As Session = Session.GetSession()
        ' ----------------------------------------------
        '   Menu: File->Options->Assembly Load Options...
        ' ----------------------------------------------
        Dim markId1 As Session.UndoMarkId
        markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start")

        theSession.SetUndoMarkName(markId1, "Assembly Load Options")

        Dim markId2 As Session.UndoMarkId
        markId2 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Assembly Load Options")

        theSession.Parts.LoadOptions.LoadLatest = False
        theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.AsSaved
        theSession.Parts.LoadOptions.ComponentsToLoad = LoadOptions.LoadComponents.None
        theSession.Parts.LoadOptions.UsePartialLoading = True
        theSession.Parts.LoadOptions.SetInterpartData(False, LoadOptions.Parent.Partial)
        theSession.Parts.LoadOptions.AbortOnFailure = False
        theSession.Parts.LoadOptions.AllowSubstitution = False
        theSession.Parts.LoadOptions.GenerateMissingPartFamilyMembers = True
        theSession.Parts.LoadOptions.ReferenceSetOverride = False

        Dim referenceSets1(4) As String
        referenceSets1(0) = "As Saved"
        referenceSets1(1) = "Entire Part"
        referenceSets1(2) = "Empty"
        referenceSets1(3) = "Use Lightweight"
        referenceSets1(4) = "Use Model"
        theSession.Parts.LoadOptions.SetDefaultReferenceSets(referenceSets1)

        Dim searchDirectories1(0) As String
        searchDirectories1(0) = "C:\Program Files\UGS\NX 7.5\UGII"
        Dim searchSubDirs1(0) As Boolean
        searchSubDirs1(0) = True
        theSession.Parts.LoadOptions.SetSearchDirectories(searchDirectories1, searchSubDirs1)

        theSession.DeleteUndoMark(markId2, Nothing)

        ' ----------------------------------------------
        '   Menu: File->Open...
        ' ----------------------------------------------

        Dim basePart1 As BasePart
        Dim partLoadStatus1 As PartLoadStatus
        basePart1 = theSession.Parts.OpenBaseDisplay(filename, partLoadStatus1)

        Dim workPart As Part = theSession.Parts.Work

        ''Dim s As String
        ''s = workPart.Leaf
        ''Dim ss As String

        Dim comp As ComponentAssembly = workPart.ComponentAssembly
        If comp Is Nothing Then
            ''ss = s & ";No Child"
            ''PrintLine(1, ss)
        Else
            If comp.RootComponent Is Nothing Then
                ''ss = s & ";No Child"
                ''PrintLine(1, ss)
            Else
                Dim children As Component() = comp.RootComponent.GetChildren()
                Dim child As Component
                For Each child In children


                    'cmd.CommandText = "Insert into IPAImport select '" & child.Name & "'"
                    cmd.CommandText = "Insert into IPAImport select '" & child.DisplayName & "'"
                    cmd.ExecuteNonQuery()

                    ''ss = s & ";" & child.Name
                    ''PrintLine(1, ss)
                Next
            End If
        End If

        partLoadStatus1.Dispose()
        Dim markId3 As Session.UndoMarkId
        markId3 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

        Dim markId4 As Session.UndoMarkId
        markId4 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

        ' ----------------------------------------------
        '   Menu: File->Close->All Parts
        ' ----------------------------------------------
        theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)

        workPart = Nothing
        theSession = Nothing

    End Sub

    Private Sub Update_IPA_List(ByVal filename As String)

        Dim pn As String
        Dim rev As String
        Dim sqlString As String


        '' Update list
        pn = mvs.Left(Path.GetFileNameWithoutExtension(filename), 8)
        rev = mvs.Right(Path.GetFileNameWithoutExtension(filename), 4)
        sqlString = "exec importIPAFromMdl '" & pn & "','" & rev & "','" & ComboBox1.SelectedValue & "','" & ComboBox2.SelectedValue & "'"

        If sqlConn.State = ConnectionState.Closed Then
            sqlConn.Open()
        End If
        cmd.CommandText = sqlString
        cmd.ExecuteNonQuery()

        '' Remove duliicates from list
        If sqlConn.State = ConnectionState.Closed Then
            sqlConn.Open()
        End If
        cmd.CommandText = "exec delete_IPA_Duplicates"
        cmd.ExecuteNonQuery()

    End Sub
   
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Get_IPAList_ComboBoxTableAdapter.Fill(Me.ChieftainDataSet.get_IPAList_ComboBox)
        TextBox1.Text = ""
        ComboBox2.SelectedValue = 0
        Button3.Enabled = True
    End Sub

 
End Class