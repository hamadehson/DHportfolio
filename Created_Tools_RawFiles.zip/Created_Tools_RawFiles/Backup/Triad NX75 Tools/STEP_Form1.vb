﻿Imports System
Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings


Public Class STEP_Form1

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub

    Private Sub STEP_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Not validate_Data() Then
            Exit Sub
        End If
        CreateDefFile()
        exportSTEP()
        MsgBox("done")
    End Sub

    Private Sub btnInputFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInputFile.Click
        TextBox1.Text = Get_file_Name_Open("part (*.prt)|*.prt|All (*.*)|*.*", "T:\")
    End Sub

    Private Sub btnExportLoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportLoc.Click
        Dim fname As String

        'fname = System.IO.Path.GetFileNameWithoutExtension(TextBox1.Text)
        fname = mvs.Left(TextBox1.Text, Len(TextBox1.Text) - 3) & "stp"


        TextBox2.Text = Get_file_Name_Save("STEP (*.stp)|*.stp|All (*.*)|*.*", fname)
    End Sub
    Private Sub exportSTEP()

        Dim STEPPath As String
        Dim InputFile As String
        Dim OutputFile As String
        Dim Params As String
        Dim STEPString As String

        STEPPath = "C:\Program Files\UGS\NX 7.5\STEP214UG\step214ug.cmd"
        InputFile = TextBox1.Text
        OutputFile = TextBox2.Text
        Params = "C:\Program Files\Triad NX Tools\export.def" '"C:\Program Files\UGS\NX 7.5\STEP214UG\ugstep214.def"

        STEPString = Chr(34) & STEPPath & Chr(34) & " " & Chr(34) & InputFile & Chr(34) & " d=" & Chr(34) & Params & Chr(34) & " o=" & Chr(34) & OutputFile & Chr(34)


        'STEPString = "C:\Progra~1\UGS\NX5.0\STEP214UG\step214ug.cmd C:\testasm\54780421.asm.0001.prt d=""C:\Program Files\UGS\NX 7.5\STEP214UG\ugstep214.def"" o=c:\testasm\test1step214.stp"


        '''  added extra attributes to hide window and wait before getting the "Done" message.  need to test.
        Shell(STEPString, AppWinStyle.Hide, True)


        ''' look at this to get response from shell
        'Dim procID As Integer
        'Dim newProc As Diagnostics.Process
        'newProc = Diagnostics.Process.Start(Shell(STEPString, AppWinStyle.Hide, True))
        'procID = newProc.Id
        'newProc.WaitForExit()
        'Dim procEC As Integer = -1
        'If newProc.HasExited Then
        '    procEC = newProc.ExitCode
        'End If
        'MsgBox("Process with ID " & CStr(procID) & _
        '    " terminated with exit code " & CStr(procEC))




    End Sub

    Private Sub STEP_Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        RadioButton1.Checked = True
    End Sub
    Private Function validate_Data() As Boolean

        validate_Data = True

        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a file to export.")
            btnInputFile.Focus()
            validate_Data = False
            Exit Function
        End If

        If TextBox2.Text Is Nothing Or TextBox2.Text = "" Then
            MsgBox("Please select a location and enter a file name for exported file.")
            btnExportLoc.Focus()
            validate_Data = False
            Exit Function
        End If

        If RadioButton2.Checked Then
            If ListBox1.Items.Count = 0 Then
                MsgBox("You have select ""Search Directries"", but did not choose any directories.  Please check your selection.")
                ListBox1.Focus()
                validate_Data = False
                Exit Function
            End If
        End If


    End Function
    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        SetLoadOptions()
    End Sub



    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        SetLoadOptions()
    End Sub

    Private Sub SetLoadOptions()
        Dim setting As Boolean

        If RadioButton1.Checked Then
            setting = False
        Else
            setting = True
        End If

        ListBox1.Visible = setting
        btnAddPath.Visible = setting
        btnDeletePath.Visible = setting
        btnClearList.Visible = setting
        Label2.Visible = setting
        btnUp.Visible = setting
        btnDown.Visible = setting



    End Sub

    Private Sub btnAddPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPath.Click
        ListBox1.Items.Add(Get_Directory())


    End Sub

    Private Sub btnDeletePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeletePath.Click
        ListBox1.Items.Remove(ListBox1.SelectedItem)

    End Sub

    Private Sub btnClearList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearList.Click
        ListBox1.Items.Clear()
    End Sub
    Private Sub moveDown()
        Dim pos As Integer = ListBox1.SelectedIndex
        If pos <> -1 Then
            If pos + 2 < ListBox1.Items.Count + 1 Then

                ListBox1.Items.Insert(pos + 2, ListBox1.SelectedItem)
                ListBox1.Items.RemoveAt(pos)
                ListBox1.SelectedIndex = pos + 1
            End If
        End If
    End Sub

    Private Sub moveUp()
        Dim pos As Integer = ListBox1.SelectedIndex
        If pos <> -1 Then
            If pos <> 0 Then
                ListBox1.Items.Insert(pos - 1, ListBox1.SelectedItem)
                ListBox1.Items.RemoveAt(pos + 1)
                ListBox1.SelectedIndex = pos - 1
            End If
        End If
    End Sub
    Private Sub btnDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDown.Click
        moveDown()
    End Sub

    Private Sub btnUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUp.Click
        moveUp()
    End Sub
    Private Sub CreateDefFile()

        If File.Exists("c:\program files\triad nx tools\export.def") Then
            Kill("c:\program files\triad nx tools\export.def")
        End If

        File.Copy("c:\program files\triad nx tools\template.def", "c:\program files\triad nx tools\export.def")

        FileOpen(1, "c:\program files\triad nx tools\export.def", OpenMode.Append)

        If RadioButton1.Checked Then
            PrintLine(1, "UGI_LOAD_OPTION = Load From Assem Dir")
            PrintLine(1, "UGI_SEARCH_DIRS =")
        Else

            Dim i As Integer
            Dim spath As String
            Dim sdirs As String
            Dim listcnt As Integer
            listcnt = ListBox1.Items.Count - 1

            sdirs = "UGI_SEARCH_DIRS = "

            For i = 0 To listcnt
                If mvs.Right(ListBox1.Items.Item(i).ToString, 1) = "\..." Then
                    spath = ListBox1.Items.Item(i).ToString
                Else
                    spath = ListBox1.Items.Item(i).ToString & "\..."
                End If


                If i <> listcnt Then
                    sdirs = sdirs & spath & "," & vbCrLf
                Else
                    sdirs = sdirs & spath
                End If


            Next
            PrintLine(1, "UGI_LOAD_OPTION = Search Directories")
            PrintLine(1, sdirs)
        End If

        FileClose(1)
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        RadioButton1.Checked = True
        ListBox1.Items.Clear()

    End Sub
End Class