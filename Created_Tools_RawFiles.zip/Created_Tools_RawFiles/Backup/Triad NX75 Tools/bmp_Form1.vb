Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies
Imports System.Windows.Forms
Imports Microsoft.VisualBasic


Public Class bmp_Form1
    Dim drs As String()
    Dim cntr As Integer

    Private Sub bmp_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click
        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        validate_Data()
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Sub validate_Data()

        Dim getsubs As Integer
        getsubs = CheckBox1.Checked
        getsubs = Math.Abs(getsubs)

        cntr = 0

        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a directory.")
            btnDirectory.Focus()
            Exit Sub
        End If

        drs = Directory.GetFiles(TextBox1.Text, "*.prt", getsubs)

        'get number of files in the dir
        cntr = drs.Length



        'display the number of files in the dir and selected attributes
        Dim t As String
        t = "You have selected """ & TextBox1.Text & """ as the directory to process." & vbCrLf _
        & "This directory contains " & cntr & " .prt files." & vbCrLf _
        & "Do you want to continue?"

        If MsgBox(t, MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        ProgressBar1.Maximum = cntr
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        Get_File_list()
        Cursor = Cursors.Arrow
        MsgBox("done")
    End Sub

    Private Sub Get_File_list()
        Dim file As String


        cntr = 0




        'enter the data into the list
        For Each file In drs


            If Path.GetFileName(file) Like "*.mdl.*.prt" Or Path.GetFileName(file) Like "*.asm.*.prt" Then
                Dim bmpFileName As String
                bmpFileName = Microsoft.VisualBasic.Left(file, Len(file) - 3) & "bmp"
                If Not IO.File.Exists(bmpFileName) Then

                    Dim theSession As Session = Session.GetSession()

                    Dim partLoadStatus1 As PartLoadStatus
                    Dim mypart As Part = theSession.Parts.Open(file, partLoadStatus1)
                    Dim width As Integer = 0
                    Dim height As Integer = 0
                    Dim pixels As Integer() = Nothing
                    mypart.GetPreviewImage(width, height, pixels)
                    Dim image1 As Bitmap = createBitmap(width, height, pixels)
                    image1.Save(bmpFileName)
                End If
            End If

            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum
            Me.Refresh()
            Application.DoEvents()
        Next


    End Sub


    Private Function createBitmap(ByVal w As Integer, ByVal h As Integer, ByVal px As Integer()) As Bitmap
        Dim bm As New Bitmap(w, h)
        For y As Integer = 0 To h - 1
            For x As Integer = 0 To w - 1
                Dim pixel As Integer = px(y * w + x)
                Dim col1 As Color = Color.FromArgb(pixel)
                Dim col2 As Color = Color.FromArgb(255, col1)
                bm.SetPixel(x, y, col2)

            Next
        Next
        Return bm
    End Function
End Class