Imports System.Windows.Forms

Public Class Chieftain_Attrib_Startup

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)

    End Sub

    Private Sub btnContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContinue.Click
        Me.Dispose()
        Dim f1 As New Chieftain_Attrib_Form1
        f1.ShowDialog()

    End Sub





    Private Sub Chieftain_Attrib_Startup_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)

    End Sub
End Class