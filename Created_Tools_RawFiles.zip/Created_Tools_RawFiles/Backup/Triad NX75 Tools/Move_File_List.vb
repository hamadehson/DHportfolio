﻿Imports System
Imports System.IO


Public Class Move_File_List

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Not validateEntries() Then
            Exit Sub
        End If

        moveFiles()
    End Sub

    Private Sub moveFiles()


        ' Create an instance of StreamReader to read from a file.
        Dim sr As StreamReader = New StreamReader(txtListFile.Text)
        Dim line As String
        ' Read and display the lines from the file until the end 
        ' of the file is reached.
        Do
            line = sr.ReadLine()

            If line Is Nothing Then
            Else
                For Each foundFile As String In My.Computer.FileSystem.GetFiles(txtSourcePath.Text, Microsoft.VisualBasic.FileIO.SearchOption.SearchTopLevelOnly, line)

                    TextBox1.Text = "Copying file: " & foundFile
                    Me.Refresh()
                    My.Computer.FileSystem.CopyFile(foundFile, txtTargetPath.Text & "\" & My.Computer.FileSystem.GetName(foundFile))
                Next
            End If


            ''File.Copy(txtSourcePath.Text & "\" & line, txtTargetPath.Text)

        Loop Until line Is Nothing
        sr.Close()
       

        MsgBox("Done")



    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        gotomain(Me)
    End Sub

    Private Sub btnGetFileList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFileList.Click
        txtListFile.Text = Get_file_Name_Open("text (*.txt)|*.txt|All (*.*)|*.*", "C:\")
        'fName = System.IO.Path.GetFileNameWithoutExtension(TextBox1.Text)
    End Sub

    Private Sub btnSelectSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelectSource.Click
        txtSourcePath.Text = Get_Directory()

    End Sub

    Private Sub btnSelectTarget_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelectTarget.Click
        txtTargetPath.Text = Get_Directory()
    End Sub

    Private Function validateEntries() As Boolean
        validateEntries = False
        If txtListFile.Text = "" Then
            MsgBox("Please enter or select the File List Text File.", MsgBoxStyle.OkOnly, "Missing File List")
            txtListFile.Focus()
            Exit Function
        End If

        If txtSourcePath.Text = "" Then
            MsgBox("Please enter or select the Source Folder.", MsgBoxStyle.OkOnly, "Missing Source Folder")
            txtSourcePath.Focus()
            Exit Function
        End If


        If txtTargetPath.Text = "" Then
            MsgBox("Please enter or select the Target File.", MsgBoxStyle.OkOnly, "Missing Target Folder")
            txtTargetPath.Focus()
            Exit Function
        End If


        validateEntries = True

    End Function

End Class