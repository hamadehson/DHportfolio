﻿Option Strict Off
Imports System
Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings

Module Module1
    Public Sub gotomain(ByVal formname As Form)
        formname.Dispose()
        Dim f1 As New MainMenu
        f1.ShowDialog()
    End Sub
    Public Function Get_file_Name_Save(ByVal filter As String, Optional ByVal Fname As String = "") As String

        Dim SaveFileDialog1 As New System.Windows.Forms.SaveFileDialog

        SaveFileDialog1.FileName = Fname
        SaveFileDialog1.InitialDirectory = "c:\"
        SaveFileDialog1.AddExtension = True
        SaveFileDialog1.Filter = filter '"Text Files (*.txt)|*.txt|All (*.*)|*.*"
        SaveFileDialog1.ShowDialog()
        Get_file_Name_Save = SaveFileDialog1.FileName.ToString()
        SaveFileDialog1.Dispose()
    End Function
    Public Function Get_file_Name_Open(ByVal filter As String, Optional ByVal InitialDir As String = "") As String

        Dim openFileDialog1 As New System.Windows.Forms.OpenFileDialog
        openFileDialog1.InitialDirectory = InitialDir ''"T:\"
        openFileDialog1.AddExtension = True
        openFileDialog1.Filter = filter '"Text Files (*.txt)|*.txt|All (*.*)|*.*"
        openFileDialog1.ShowDialog()
        Get_file_Name_Open = openFileDialog1.FileName.ToString()
        openFileDialog1.Dispose()
    End Function

    Public Function Get_Directory() As String
        Dim FolderBrowserDialog1 As New System.Windows.Forms.FolderBrowserDialog

        ' open a dialog box to select the target folder
        FolderBrowserDialog1.Description = "Select The folder to be used"
        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer
        FolderBrowserDialog1.ShowNewFolderButton = True
        FolderBrowserDialog1.ShowDialog()
        Get_Directory = FolderBrowserDialog1.SelectedPath
        FolderBrowserDialog1.Dispose()
    End Function
End Module
