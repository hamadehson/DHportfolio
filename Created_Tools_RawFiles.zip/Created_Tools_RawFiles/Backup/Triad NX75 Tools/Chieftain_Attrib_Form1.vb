Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies
Imports System.Windows.Forms

Public Class Chieftain_Attrib_Form1
    Dim drs As String()
    Dim cntr As Integer

    Private Sub Chieftain_Attrib_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click
        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        If Not validate_Data() Then
            Exit Sub

        End If
        ProgressBar1.Maximum = cntr
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        Get_File_list()
        Cursor = Cursors.Arrow
        MsgBox("done")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFile.Click

        TextBox3.Text = Get_file_Name_Save("Text Files (*.txt)|*.txt|All (*.*)|*.*")
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Function validate_Data() As Boolean

        validate_Data = False
        Dim getsubs As Integer
        getsubs = CheckBox1.Checked
        getsubs = Math.Abs(getsubs)

        cntr = 0

        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a directory.")
            btnDirectory.Focus()
            Exit Function
        End If

        If TextBox3.Text Is Nothing Or TextBox3.Text = "" Then
            MsgBox("Please select a file.")
            BtnFile.Focus()
            Exit Function
        End If


        drs = Directory.GetFiles(TextBox1.Text, "*.prt", getsubs)

        'get number of files in the dir
        cntr = drs.Length



        'display the number of files in the dir and selected attributes
        Dim t As String
        t = "You have selected """ & TextBox1.Text & """ as the directory to process." & vbCrLf _
        & "This directory contains " & cntr & " .prt files." & vbCrLf _
        & "The text file for the list will be written to """ & TextBox3.Text & ".""" & vbCrLf & vbCrLf _
        & "Do you want to continue?"

        If MsgBox(t, MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Function
        End If

        validate_Data = True
    End Function

    Private Sub Get_File_list()
        Dim file As String
        cntr = 0

        ' --- Open file for text output
        FileOpen(1, TextBox3.Text, OpenMode.Output)
        PrintLine(1, "File_Name;Part Number;Revision;Description;Material Specification;Material Thickness;Finish Specification;Performance Specification")
        'enter the data into the list
        For Each file In drs
            Dim theSession As Session = Session.GetSession()
            ' ----------------------------------------------
            '   Menu: File->Options->Assembly Load Options...
            ' ----------------------------------------------
            Dim markId1 As Session.UndoMarkId
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start")

            theSession.SetUndoMarkName(markId1, "Assembly Load Options")

            Dim markId2 As Session.UndoMarkId
            markId2 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Assembly Load Options")

            theSession.Parts.LoadOptions.LoadLatest = False

            theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.FromDirectory

            theSession.Parts.LoadOptions.ComponentsToLoad = LoadOptions.LoadComponents.None

            theSession.Parts.LoadOptions.UsePartialLoading = True

            theSession.Parts.LoadOptions.SetInterpartData(False, LoadOptions.Parent.Partial)

            theSession.Parts.LoadOptions.AbortOnFailure = False

            theSession.Parts.LoadOptions.AllowSubstitution = False

            theSession.Parts.LoadOptions.GenerateMissingPartFamilyMembers = False

            theSession.Parts.LoadOptions.ReferenceSetOverride = False

            Dim referenceSets1(4) As String
            referenceSets1(0) = "As Saved"
            referenceSets1(1) = "Entire Part"
            referenceSets1(2) = "Empty"
            referenceSets1(3) = "Use Lightweight"
            referenceSets1(4) = "Use Model"
            theSession.Parts.LoadOptions.SetDefaultReferenceSets(referenceSets1)

            Dim searchDirectories1(0) As String
            searchDirectories1(0) = "C:\Program Files\UGS\NX 7.5\UGII"
            Dim searchSubDirs1(0) As Boolean
            searchSubDirs1(0) = True
            theSession.Parts.LoadOptions.SetSearchDirectories(searchDirectories1, searchSubDirs1)

            theSession.DeleteUndoMark(markId2, Nothing)

            ' ----------------------------------------------
            '   Menu: File->Open...
            ' ----------------------------------------------

            Dim basePart1 As BasePart
            Dim partLoadStatus1 As PartLoadStatus
            Dim partNum As String = ""
            Dim revision As String = ""
            Dim matSpec As String = ""
            Dim matThick As String = ""
            Dim partDesc As String = ""
            Dim partFinish As String = ""
            Dim perfSpec As String = ""





            Try
                basePart1 = theSession.Parts.OpenBaseDisplay(file, partLoadStatus1)


                Dim workPart As Part = theSession.Parts.Work




                ' ----------------------------------------------
                ' the code below will gather all of the attributes
                ' -------------------------------------------------
                'Dim attInfo() As NXObject.AttributeInformation = _
                ' workPart.GetAttributeTitlesByType(NXObject.AttributeType.String)
                'Dim aValue As String = Nothing
                'For Each ai As NXObject.AttributeInformation In attInfo
                '    aValue = workPart.GetStringAttribute(ai.Title)
                '    PrintLine(1, fname & ": " & ai.Title & " = " & aValue)
                'Next

                ' -------------------------------------------------------------

                Dim attInfo() As NXObject.AttributeInformation = _
                 workPart.GetAttributeTitlesByType(NXObject.AttributeType.String)
                Dim aValue As String = Nothing
                For Each ai As NXObject.AttributeInformation In attInfo

                    MsgBox(ai.Title.ToString)


                    Select Case ai.Title.ToString
                        Case "PART_NUMBER"
                            partNum = workPart.GetStringAttribute(ai.Title).ToString
                        Case "REVISION"
                            revision = workPart.GetStringAttribute(ai.Title).ToString
                        Case "PART_DESCRIPTION"
                            partDesc = workPart.GetStringAttribute(ai.Title).ToString
                            partDesc = Trim(partDesc)
                            While InStr(partDesc, Chr(10)) <> 0
                                partDesc = Replace(partDesc, Chr(10), " ")
                            End While
                            While InStr(partDesc, Chr(9)) <> 0
                                partDesc = Replace(partDesc, Chr(9), "")
                            End While

                        Case "MATERIAL_SPECIFICATION"
                            matSpec = workPart.GetStringAttribute(ai.Title).ToString

                            matSpec = Trim(matSpec)
                            While InStr(matSpec, Chr(10)) <> 0
                                matSpec = Replace(matSpec, Chr(10), " ")
                            End While

                            While InStr(matSpec, Chr(9)) <> 0
                                matSpec = Replace(matSpec, Chr(9), "")
                            End While

                        Case "MATERIAL_THICKNESS"
                            matThick = workPart.GetStringAttribute(ai.Title).ToString
                            matThick = Trim(matThick)
                            While InStr(matThick, Chr(10)) <> 0
                                matThick = Replace(matThick, Chr(10), " ")
                            End While
                            While InStr(matThick, Chr(9)) <> 0
                                matThick = Replace(matThick, Chr(9), "")
                            End While

                        Case "FINISH_SPECIFICATION"
                            partFinish = workPart.GetStringAttribute(ai.Title).ToString
                            partFinish = Trim(partFinish)
                            While InStr(partFinish, Chr(10)) <> 0
                                partFinish = Replace(partFinish, Chr(10), " ")
                            End While
                            While InStr(partFinish, Chr(9)) <> 0
                                partFinish = Replace(partFinish, Chr(9), "")
                            End While

                        Case "PERFORMANCE_SPECIFICATION"
                            perfSpec = workPart.GetStringAttribute(ai.Title).ToString
                            perfSpec = Trim(perfSpec)
                            While InStr(perfSpec, Chr(10)) <> 0
                                perfSpec = Replace(perfSpec, Chr(10), " ")
                            End While
                            While InStr(perfSpec, Chr(9)) <> 0
                                perfSpec = Replace(perfSpec, Chr(9), "")
                            End While




                    End Select

                Next

                PrintLine(1, file & ";" & partNum & ";" & revision & ";" & partDesc & ";" & matSpec & ";" & matThick & ";" & partDesc & ";" & partFinish & ";" & perfSpec)

                partLoadStatus1.Dispose()
                Dim markId3 As Session.UndoMarkId
                markId3 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

                Dim markId4 As Session.UndoMarkId
                markId4 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

                ' ----------------------------------------------
                '   Menu: File->Close->All Parts
                ' ----------------------------------------------
                theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)

                workPart = Nothing
            Catch
                PrintLine(1, file & "; BAD FILE " & partNum & ";" & revision & ";" & partDesc & ";" & matSpec & ";" & matThick & ";" & partDesc & ";" & partFinish & ";" & perfSpec)
            End Try

            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum
            Me.Refresh()
            Application.DoEvents()

        Next
        'close the text file
        FileClose(1)

    End Sub
End Class