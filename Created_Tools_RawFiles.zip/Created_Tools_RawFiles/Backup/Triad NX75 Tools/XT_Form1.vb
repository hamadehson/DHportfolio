﻿Option Strict Off

Imports System
Imports System.Collections
Imports NXOpen
Imports NXOpen.UF
Imports NXOpen.UI
Imports NXOpen.Utilities

Public Class XT_Form1


    'Module export_all_bodies_to_parasolid

    Dim s As Session = Session.GetSession()
    Dim ufs As UFSession = UFSession.GetUFSession()

    Public Function GetUnloadOption(ByVal dummy As String) As Integer

        GetUnloadOption = UFConstants.UF_UNLOAD_IMMEDIATELY

    End Function

    'End Module

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim inx As Integer = 0
        Dim cntr As Integer = 0
        'Dim dispPart As Part = s.Parts.Display
        Dim workPart As Part = s.Parts.Work
        'Dim n As String = vbCrLf

        'Dim bodies As BodyCollection = dispPart.Bodies
        Dim bodies As BodyCollection = workPart.Bodies
        Dim bodyCount As Integer = bodies.ToArray.Length
        'Dim tagList(bodyCount - 1) As NXOpen.Tag
        Dim tagList(0) As NXOpen.Tag

        Do
            'tagList(inx) = dispPart.Bodies.ToArray(inx).Tag
            If workPart.Bodies.ToArray(inx).Layer = 1 Then

                If cntr <> 0 Then
                    Array.Resize(tagList, tagList.Length + 1)
                End If

                tagList(cntr) = workPart.Bodies.ToArray(inx).Tag


                cntr = cntr + 1


            End If

            inx = inx + 1

        Loop Until inx = bodyCount

        ufs.Ps.ExportData(tagList, "C:\export_test1.x_t")

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        'GetUnloadOption(1)
        gotomain(Me)
    End Sub

    Private Sub XT_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        'GetUnloadOption(1)
        gotomain(Me)
    End Sub
End Class