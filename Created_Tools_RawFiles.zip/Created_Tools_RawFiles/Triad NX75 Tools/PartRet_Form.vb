﻿Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings
Imports System.Data.SqlClient

Public Class PartRet_Form

    Dim drs As String()

    Private Sub btnfindfiles_Click(sender As Object, e As EventArgs) Handles BtnFindFiles.Click

        Dim conn = New SqlConnection("Server=databasesvr3;DataBase=Chieftain;User Id=dhamadeh;Password=dan12345")
        Dim cmd As New SqlCommand
        Dim ds As SqlDataReader

        Dim FilePartNum As String
        Dim FileRev As String
        Dim FileRevType As String
        Dim Filetype As String
        Dim dpath As String
        Dim PartNum As String
        Dim Dwg As String
        Dim Mdl As String
        Dim Count As Integer
        Dim Count2 As Integer
        Dim FCount As Integer

        '''' Field Checks -----------------------------------------------------------------------------------------------

        If txtPN.Text = "" Then
            MsgBox("Please select a Part Number.", MsgBoxStyle.OkOnly, "No Part Number Selected")
            Exit Sub
        Else
            PartNum = txtPN.Text
        End If

        If txtRev.Text = "" Or txtMdl.Text = "" Then
            MsgBox("Please select a DwgRev/MdlRev Number.", MsgBoxStyle.OkOnly, "No Rev Number Selected")
            Exit Sub
        Else
            Dwg = txtRev.Text
            Mdl = txtMdl.Text
        End If

        If txtSearch.Text = "" Then
            MsgBox("Please select a folder to search.", MsgBoxStyle.OkOnly, "No Search Folder Selected")
            Exit Sub
        End If

        If txtDest.Text = "" Then
            MsgBox("Please select a folder to copy files to.", MsgBoxStyle.OkOnly, "No Destination Folder Selected")
            Exit Sub
        Else
            dpath = txtDest.Text
        End If

        If Not My.Computer.FileSystem.DirectoryExists(dpath) Then
            MsgBox("the destination folder does not exist", MsgBoxStyle.OkOnly, "Destination Folder Error")
            Exit Sub
        End If

        If RadioButton1.Checked = True Then

            Count = 0
            Count2 = 0
            FCount = txtSearch.TextLength
            drs = Directory.GetFiles(txtSearch.Text, mvs.Left(txtPN.Text, 4) + "*")

            '''' Find & Copy Files -----------------------------------------------------------------------------------------------
            For Each fcheck In drs

                '''' check PartNum & Revs
                FilePartNum = mvs.Mid(fcheck, FCount + 2, 8)
                FileRevType = mvs.Mid(fcheck, FCount + 11, 4)
                FileRev = mvs.Mid(fcheck, FCount + 16, 4)
                Filetype = mvs.Right(fcheck, 3)

                If (FileRevType = "dwg." Or FileRevType = "mdl." Or FileRevType = "asm.") Then
                    FileRev = mvs.Mid(fcheck, FCount + 15, 4)
                    FileRevType = mvs.Mid(fcheck, FCount + 11, 3)
                End If

                If (FileRevType = "dwg" Or FileRevType = "edwg") And (FilePartNum = PartNum) And (FileRev = Dwg) Then
                    FileSystem.FileCopy(fcheck, dpath & "\" & FilePartNum & "." & FileRev & "." & FileRevType & "." & Filetype)
                    Count = Count + 1
                End If

                If (FileRevType = "mdl" Or FileRevType = "easm" Or FileRevType = "asm") And (FilePartNum = PartNum) And (FileRev = Mdl) Then
                    FileSystem.FileCopy(fcheck, dpath & "\" & FilePartNum & "." & FileRev & "." & FileRevType & "." & Filetype)
                    Count2 = Count2 + 1
                End If

            Next



            If Count = 0 And Count2 = 0 Then
                MsgBox("No Files with the Part Number or Revs were found", MsgBoxStyle.OkOnly, "Error: No Files")
            Else
                MsgBox("There were " & Count & " files copied with the Part Number & DwgRev of: " & PartNum & "." & Dwg & ", and there were " & Count2 & " files copied with the Part Number & MdlRev of: " & PartNum & "." & Mdl, MsgBoxStyle.OkOnly, "Success")
            End If

        ElseIf RadioButton2.Checked = True Then

            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "Part_Tree_Ret"
            cmd.Connection = conn
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@PartNum", txtPN.Text)
            cmd.Parameters.AddWithValue("@Dwg", txtRev.Text)
            cmd.Parameters.AddWithValue("@Mdl", txtMdl.Text)

            Count = 0
            FCount = txtSearch.TextLength
            drs = Directory.GetFiles(txtSearch.Text, mvs.Left(txtPN.Text, 4) + "*")

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            ds = cmd.ExecuteReader(CommandBehavior.CloseConnection)

            ds.Close()

            For Each fcheck In drs

                FilePartNum = mvs.Mid(fcheck, FCount + 2, 8)
                FileRevType = mvs.Mid(fcheck, FCount + 11, 4)
                FileRev = mvs.Mid(fcheck, FCount + 16, 4)
                Filetype = mvs.Right(fcheck, 3)

                If (FileRevType = "dwg." Or FileRevType = "mdl." Or FileRevType = "asm.") Then
                    FileRev = mvs.Mid(fcheck, FCount + 15, 4)
                    FileRevType = mvs.Mid(fcheck, FCount + 11, 3)
                End If

                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "PartRetCheck"
                cmd.Connection = conn
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@PartNum", FilePartNum)
                cmd.Parameters.AddWithValue("@Rev", FileRev)

                If conn.State = ConnectionState.Closed Then
                    conn.Open()
                End If

                ds = cmd.ExecuteReader(CommandBehavior.CloseConnection)

                Try

                    If ds.Read() Then
                        FileSystem.FileCopy(fcheck, dpath & "\" & FilePartNum & "." & FileRev & "." & FileRevType & "." & Filetype)
                        Count = Count + 1
                    End If

                Finally
                    ds.Close()
                End Try

            Next

            If Count = 0 Then
                MsgBox("There were no files found or moved with this Part Number/Revs.", MsgBoxStyle.OkOnly, "Error: No Files")
            Else
                MsgBox("A total of " + Count + " files were copied into the specified directory.", MsgBoxStyle.OkOnly, "Success")
            End If

        Else

            MsgBox("Please Select a File Retrieval Mode", MsgBoxStyle.OkOnly, "Error")

        End If

    End Sub

    Private Sub btnGetDest_Click(sender As Object, e As EventArgs) Handles btnGetDest.Click

        Dim dialog As New FolderBrowserDialog()
        Dim apppath As String

        dialog.RootFolder = Environment.SpecialFolder.Desktop
        dialog.SelectedPath = "C:\"
        dialog.Description = "Select Destination Folder"

        If dialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            apppath = dialog.SelectedPath
            txtDest.Text = apppath
        End If

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            RadioButton2.Checked = False
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            RadioButton1.Checked = False
        End If
    End Sub

    Private Sub txtSourceBtn_Click(sender As Object, e As EventArgs) Handles txtSourceBtn.Click

        Dim dialog As New FolderBrowserDialog()
        Dim apppath As String

        dialog.RootFolder = Environment.SpecialFolder.Desktop
        dialog.SelectedPath = "C:\"
        dialog.Description = "Select Destination Folder"

        If dialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            apppath = dialog.SelectedPath
            txtSearch.Text = apppath
        End If

    End Sub
End Class

