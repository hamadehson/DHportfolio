Option Strict Off
Imports System
Imports System.IO
Imports NXOpen
Imports NXOpen.assemblies
Imports System.Windows.Forms
Imports mvs = Microsoft.VisualBasic.Strings


Public Class PDF_Form1
    Dim drs As String()
    Dim cntr As Integer
    Dim exclusionFile As String
    Dim dwgFiles As String()
    Dim pdfComplete As Boolean

    Private Sub PDF_Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        gotomain(Me)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = False
        RadioButton1.Checked = True
        CheckBox3.Checked = False

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDirectory.Click

        If CheckBox3.Checked Then
            MsgBox("Start Get Directory Function")
        End If

        TextBox1.Text = Get_Directory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        validate_Data()
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        gotomain(Me)
    End Sub


    Private Sub validate_Data()

        If CheckBox3.Checked Then
            MsgBox("Start Validate_Data sub")
        End If

        Dim getsubs As Integer
        Dim filefilter As String
        Dim filecheck As Boolean

        If CheckBox3.Checked Then
            MsgBox("Set exclusionFile value")
        End If

        exclusionFile = TextBox1.Text & "\PDFExclusionFile.txt"

        If CheckBox3.Checked Then
            MsgBox("exclusionFile value = " & exclusionFile)
        End If

        If CheckBox3.Checked Then
            MsgBox("Check for presence for exclusion file")
        End If

        If Not File.Exists(exclusionFile) Then
            If CheckBox3.Checked Then
                MsgBox("No exclusion file - create file")
            End If
            FileOpen(1, exclusionFile, OpenMode.Output)
            FileClose(1)
        End If


        filefilter = txtFilter.Text
        getsubs = CheckBox1.Checked
        getsubs = Math.Abs(getsubs)

        cntr = 0
        ReDim dwgFiles(cntr)

        ' make sure a directory was selected
        If TextBox1.Text Is Nothing Or TextBox1.Text = "" Then
            MsgBox("Please select a directory.", , "Directory Check")
            btnDirectory.Focus()
            Exit Sub
        End If

        If filefilter Is Nothing Or filefilter = "" Then
            MsgBox("Please enter a filter string or unselect the ""Use custom Filter Box""", , "Filter Check")
            Exit Sub
        End If


        If CheckBox3.Checked Then
            MsgBox("Get list of files to check")
        End If


        ' get list of files in the dir
        drs = Directory.GetFiles(TextBox1.Text, filefilter, getsubs)

        If CheckBox3.Checked Then
            MsgBox(drs.Length & " files to check")
        End If

        If CheckBox3.Checked Then
            MsgBox("Get list of exclusion files")
        End If

        Dim lines = File.ReadAllLines(exclusionFile)

        If CheckBox3.Checked Then
            MsgBox(lines.Length & " exclusion files")
        End If


        If CheckBox3.Checked Then
            MsgBox("Start file check")
        End If

        For Each fcheck In drs


            Dim pdfFile As String
            ' set pdf file
            pdfFile = mvs.Left(fcheck, Len(fcheck) - 4) & ".pdf"

            If CheckBox3.Checked Then
                MsgBox("check " & pdfFile)
            End If

            If Not File.Exists(pdfFile) Then

                filecheck = False

                If CheckBox3.Checked Then
                    MsgBox("PDF file does not exist")
                End If

                For Each Line In lines
                    If CheckBox3.Checked Then
                        MsgBox("Check " & LCase(fcheck) & " = " & LCase(Line))
                    End If
                    If LCase(fcheck) = LCase(Line) Then
                        filecheck = True
                        If CheckBox3.Checked Then
                            MsgBox("file is in exclusion list")
                        End If
                        GoTo j1
                    Else
                        If CheckBox3.Checked Then
                            MsgBox("file is not in exclusion list")
                        End If

                    End If
j1:
                Next

                If filecheck Then
                    GoTo jump
                End If

                ReDim Preserve dwgFiles(cntr)
                dwgFiles(cntr) = fcheck
                cntr = cntr + 1

jump:
            Else
                If CheckBox3.Checked Then
                    MsgBox("PDF file does exist")
                End If
            End If
        Next

        If cntr = 0 Then
            MsgBox("There are no files in the directory selected requiring pdf files", , "PDF File Check")
            Exit Sub

        Else
            'display the number of files in the dir and selected attributes
            Dim t As String
            t = "You have selected """ & TextBox1.Text & """ as the directory to process." & vbCrLf _
            & "This directory contains " & cntr & " " & filefilter & " files." & vbCrLf _
                   & "Do you want to continue?"

            If MsgBox(t, MsgBoxStyle.YesNo, "PDF File Check") = MsgBoxResult.No Then
                Exit Sub
            End If
        End If



        btnProcess.Enabled = False
        btnQuit.Enabled = False



        ProgressBar1.Maximum = cntr
        ProgressBar1.Visible = True
        Cursor = Cursors.WaitCursor
        TextBox2.Text = "0 of " & ProgressBar1.Maximum
        Me.Refresh()



        Get_File_list()
        Cursor = Cursors.Arrow
        MsgBox("done")

        btnProcess.Enabled = True
        btnQuit.Enabled = True

        If CheckBox3.Checked Then
            MsgBox("End Validate_Data sub")
        End If

    End Sub

    Private Sub Get_File_list()

        cntr = 0

        'enter the data into the list
        'For Each pfile In drs
        For Each pfile In dwgFiles


            Dim pdfFile As String

            ' set pdf file
            pdfFile = mvs.Left(pfile, Len(pfile) - 4) & ".pdf"

            TextBox3.Text = Path.GetFileName(pfile)
            Me.Refresh()
            Application.DoEvents()

            createPDF(pfile, pdfFile)

            cntr = cntr + 1
            ProgressBar1.Increment(1)
            ProgressBar1.Refresh()
            TextBox2.Text = cntr & " of " & ProgressBar1.Maximum
            Me.Refresh()
            'Application.DoEvents()





        Next


    End Sub



    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        SetLoadOptions()
    End Sub



    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        SetLoadOptions()
    End Sub

    Private Sub SetLoadOptions()
        Dim setting As Boolean

        If RadioButton1.Checked Then
            setting = False
        Else
            setting = True
        End If

        ListBox1.Visible = setting
        btnAddPath.Visible = setting
        btnDeletePath.Visible = setting
        btnClearList.Visible = setting
        Label2.Visible = setting
        btnUp.Visible = setting
        btnDown.Visible = setting



    End Sub

    Private Sub btnAddPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPath.Click
        ListBox1.Items.Add(Get_Directory())


    End Sub

    Private Sub btnDeletePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeletePath.Click
        ListBox1.Items.Remove(ListBox1.SelectedItem)

    End Sub

    Private Sub btnClearList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearList.Click
        ListBox1.Items.Clear()
    End Sub
    Private Sub moveDown()
        Dim pos As Integer = ListBox1.SelectedIndex
        If pos <> -1 Then
            If pos + 2 < ListBox1.Items.Count + 1 Then

                ListBox1.Items.Insert(pos + 2, ListBox1.SelectedItem)
                ListBox1.Items.RemoveAt(pos)
                ListBox1.SelectedIndex = pos + 1
            End If
        End If
    End Sub

    Private Sub moveUp()
        Dim pos As Integer = ListBox1.SelectedIndex
        If pos <> -1 Then
            If pos <> 0 Then
                ListBox1.Items.Insert(pos - 1, ListBox1.SelectedItem)
                ListBox1.Items.RemoveAt(pos + 1)
                ListBox1.SelectedIndex = pos - 1
            End If
        End If
    End Sub
    Private Sub btnDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDown.Click
        moveDown()
    End Sub

    Private Sub btnUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUp.Click
        moveUp()
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            txtFilter.Visible = True
        Else
            txtFilter.Visible = False
        End If

        txtFilter.Text = "*.prt"
    End Sub


    Public Sub createPDF(ByVal pfile As String, ByVal pdffile As String)



        Dim theSession As Session '= Session.GetSession()

        theSession = Session.GetSession()

        ' ----------------------------------------------
        '   Menu: File->Options->Assembly Load Options...
        ' ----------------------------------------------
        Dim markId1 As Session.UndoMarkId
        markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start")

        theSession.SetUndoMarkName(markId1, "Assembly Load Options")

        Dim markId2 As Session.UndoMarkId
        markId2 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Assembly Load Options")

        theSession.Parts.LoadOptions.LoadLatest = False

        'theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.FromDirectory

        theSession.Parts.LoadOptions.ComponentsToLoad = LoadOptions.LoadComponents.All

        theSession.Parts.LoadOptions.UsePartialLoading = True

        theSession.Parts.LoadOptions.SetInterpartData(False, LoadOptions.Parent.Partial)

        theSession.Parts.LoadOptions.AbortOnFailure = False

        theSession.Parts.LoadOptions.AllowSubstitution = False

        theSession.Parts.LoadOptions.GenerateMissingPartFamilyMembers = True

        theSession.Parts.LoadOptions.ReferenceSetOverride = False

        Dim referenceSets1(4) As String
        referenceSets1(0) = "As Saved"
        referenceSets1(1) = "Entire Part"
        referenceSets1(2) = "Empty"
        referenceSets1(3) = "Use Lightweight"
        referenceSets1(4) = "Use Model"
        theSession.Parts.LoadOptions.SetDefaultReferenceSets(referenceSets1)

        'Dim searchDirectories1(1) As String
        'searchDirectories1(0) = "C:\dwgtest"
        'searchDirectories1(1) = "T:\GMX569\Release_Data\"
        'Dim searchSubDirs1(1) As Boolean
        'searchSubDirs1(0) = True
        'searchSubDirs1(1) = True
        'theSession.Parts.LoadOptions.SetSearchDirectories(searchDirectories1, searchSubDirs1)


        If RadioButton2.Checked Then

            theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.SearchDirectories

            '' set counter to number of entries
            Dim cnt As Integer = ListBox1.Items.Count - 1
            '' create searchDirectories1 array
            Dim searchDirectories1(cnt) As String
            '' Fill array
            For a As Integer = 0 To cnt
                searchDirectories1(a) = ListBox1.Items.Item(a).ToString & "\"
            Next a

            Dim searchSubDirs1(cnt) As Boolean
            For b As Integer = 0 To cnt
                searchSubDirs1(b) = True
            Next b
            theSession.Parts.LoadOptions.SetSearchDirectories(searchDirectories1, searchSubDirs1)

        Else
            theSession.Parts.LoadOptions.ComponentLoadMethod = LoadOptions.LoadMethod.FromDirectory

        End If

        'theSession.DeleteUndoMark(markId2, Nothing)

        ' ----------------------------------------------
        '   Menu: File->Open...
        ' ----------------------------------------------

        Dim basePart1 As BasePart
        Dim partLoadStatus1 As PartLoadStatus
        partLoadStatus1 = Nothing

        Try

            basePart1 = theSession.Parts.OpenBaseDisplay(pfile, partLoadStatus1)

            Dim workPart As Part = theSession.Parts.Work
            Dim displayPart As Part = theSession.Parts.Display
            Dim dwgs As Drawings.DrawingSheetCollection
            Dim sheet As Drawings.DrawingSheet
            Dim dwgsheetcount As Integer

            Dim i As Integer
            Dim partUnits As Integer

            dwgs = workPart.DrawingSheets

            ' get count of sheets in file 0 = not a drawing file
            dwgsheetcount = dwgs.ToArray.Length

            'check count 0 = not a drawing file skip process
            If dwgsheetcount <> 0 Then

                'get drawing unit
                partUnits = displayPart.PartUnits
                '0 = inch
                '1 = metric


                ' set counter to 0
                i = 0

                'start looping through drawign sheets
                For Each sheet In dwgs

                    i = i + 1

                    'Try
                    'export to pdf function

                    'set printpdfbuilder configuration
                    Dim printPDFBuilder1 As PrintPDFBuilder

                    printPDFBuilder1 = workPart.PlotManager.CreatePrintPdfbuilder()
                    printPDFBuilder1.Scale = 1.0
                    printPDFBuilder1.Colors = PrintPDFBuilder.Color.BlackOnWhite
                    printPDFBuilder1.Size = PrintPDFBuilder.SizeOption.ScaleFactor
                    If partUnits = 0 Then
                        printPDFBuilder1.Units = PrintPDFBuilder.UnitsOption.English
                    Else
                        printPDFBuilder1.Units = PrintPDFBuilder.UnitsOption.Metric
                    End If
                    printPDFBuilder1.XDimension = sheet.Height
                    printPDFBuilder1.YDimension = sheet.Length
                    ' printPDFBuilder1.OutputText = PrintPDFBuilder.OutputTextOption.Polylines
                    printPDFBuilder1.RasterImages = True
                    printPDFBuilder1.ImageResolution = PrintPDFBuilder.ImageResolutionOption.Medium
                    printPDFBuilder1.Append = True
                    printPDFBuilder1.Watermark = ""

                    Dim sheets1(0) As NXObject
                    Dim drawingSheet1 As Drawings.DrawingSheet = CType(sheet, Drawings.DrawingSheet)

                    sheets1(0) = drawingSheet1
                    printPDFBuilder1.SourceBuilder.SetSheets(sheets1)

                    printPDFBuilder1.Filename = pdffile

                    Dim nXObject1 As NXObject
                    nXObject1 = printPDFBuilder1.Commit()

                    printPDFBuilder1.Destroy()



                Next

            End If
            workPart = Nothing
        Catch ex As Exception
            FileOpen(1, exclusionFile, OpenMode.Append)
            PrintLine(1, pfile)
            FileClose(1)
            'MsgBox("Error occurred in PDF export" & vbCrLf & ex.Message & vbCrLf & "journal exiting", vbCritical + vbOKOnly)
            'Exit Sub
        End Try


        'partLoadStatus1.Dispose()

        Dim markId3 As Session.UndoMarkId
        markId3 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

        Dim markId4 As Session.UndoMarkId
        markId4 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Enter Gateway")

        ' ----------------------------------------------
        '   Menu: File->Close->All Parts
        ' ----------------------------------------------
        'workPart = Nothing
        theSession.Parts.CloseAll(BasePart.CloseModified.CloseModified, Nothing)

        theSession = Nothing
        Application.DoEvents()



    End Sub



    
End Class