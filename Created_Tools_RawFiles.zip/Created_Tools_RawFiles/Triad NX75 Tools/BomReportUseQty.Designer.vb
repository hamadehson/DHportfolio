﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BomReportUseQty
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BomReportUseQty))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.LblStep1 = New System.Windows.Forms.Label()
        Me.LblStart = New System.Windows.Forms.Label()
        Me.btnP1Cancel = New System.Windows.Forms.Button()
        Me.btnP1Next = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BtnRemVeh = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtQty = New System.Windows.Forms.TextBox()
        Me.CmbVeh = New System.Windows.Forms.ComboBox()
        Me.BtnDelVeh = New System.Windows.Forms.Button()
        Me.BtnAddVeh = New System.Windows.Forms.Button()
        Me.LBVeh = New System.Windows.Forms.ListBox()
        Me.ChkSpecNote = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ChkIncIA = New System.Windows.Forms.CheckBox()
        Me.ChkExcTMF = New System.Windows.Forms.CheckBox()
        Me.ChkExcPIA = New System.Windows.Forms.CheckBox()
        Me.ChkIncPO = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ChkLvl2 = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbAssemIA = New System.Windows.Forms.ComboBox()
        Me.gbReportType = New System.Windows.Forms.GroupBox()
        Me.RadioButton12 = New System.Windows.Forms.RadioButton()
        Me.RadioButton13 = New System.Windows.Forms.RadioButton()
        Me.btnSpecAssem = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnP2Back = New System.Windows.Forms.Button()
        Me.btnP2Cancel = New System.Windows.Forms.Button()
        Me.btnP2Next = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.RadioButton23 = New System.Windows.Forms.RadioButton()
        Me.RadioButton24 = New System.Windows.Forms.RadioButton()
        Me.RadioButton25 = New System.Windows.Forms.RadioButton()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.RadioButton26 = New System.Windows.Forms.RadioButton()
        Me.RadioButton27 = New System.Windows.Forms.RadioButton()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.RadioButton28 = New System.Windows.Forms.RadioButton()
        Me.RadioButton29 = New System.Windows.Forms.RadioButton()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.RadioButton30 = New System.Windows.Forms.RadioButton()
        Me.RadioButton31 = New System.Windows.Forms.RadioButton()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton22 = New System.Windows.Forms.RadioButton()
        Me.RadioButton18 = New System.Windows.Forms.RadioButton()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.RadioButton17 = New System.Windows.Forms.RadioButton()
        Me.RadioButton16 = New System.Windows.Forms.RadioButton()
        Me.RadioButton15 = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.RadioButton14 = New System.Windows.Forms.RadioButton()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.btnP3Back = New System.Windows.Forms.Button()
        Me.btnP3Cancel = New System.Windows.Forms.Button()
        Me.btnP3Next = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Barlbl = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.btnFinal = New System.Windows.Forms.Button()
        Me.btnP4Back = New System.Windows.Forms.Button()
        Me.btnP4Cancel = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gbReportType.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1193, 706)
        Me.TabControl1.TabIndex = 0
        Me.TabControl1.UseWaitCursor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.LblStep1)
        Me.TabPage1.Controls.Add(Me.LblStart)
        Me.TabPage1.Controls.Add(Me.btnP1Cancel)
        Me.TabPage1.Controls.Add(Me.btnP1Next)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1185, 677)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Getting Started"
        Me.TabPage1.UseVisualStyleBackColor = True
        Me.TabPage1.UseWaitCursor = True
        '
        'LblStep1
        '
        Me.LblStep1.Font = New System.Drawing.Font("Microsoft New Tai Lue", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblStep1.ForeColor = System.Drawing.Color.SteelBlue
        Me.LblStep1.Location = New System.Drawing.Point(63, 43)
        Me.LblStep1.Name = "LblStep1"
        Me.LblStep1.Size = New System.Drawing.Size(571, 43)
        Me.LblStep1.TabIndex = 3
        Me.LblStep1.Text = "Step 1 of 4 - Getting Started"
        Me.LblStep1.UseWaitCursor = True
        '
        'LblStart
        '
        Me.LblStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblStart.Location = New System.Drawing.Point(70, 122)
        Me.LblStart.Name = "LblStart"
        Me.LblStart.Size = New System.Drawing.Size(1040, 436)
        Me.LblStart.TabIndex = 2
        Me.LblStart.Text = resources.GetString("LblStart.Text")
        Me.LblStart.UseWaitCursor = True
        '
        'btnP1Cancel
        '
        Me.btnP1Cancel.Location = New System.Drawing.Point(46, 617)
        Me.btnP1Cancel.Name = "btnP1Cancel"
        Me.btnP1Cancel.Size = New System.Drawing.Size(120, 32)
        Me.btnP1Cancel.TabIndex = 1
        Me.btnP1Cancel.Text = "Close"
        Me.btnP1Cancel.UseVisualStyleBackColor = True
        Me.btnP1Cancel.UseWaitCursor = True
        '
        'btnP1Next
        '
        Me.btnP1Next.Location = New System.Drawing.Point(1019, 617)
        Me.btnP1Next.Name = "btnP1Next"
        Me.btnP1Next.Size = New System.Drawing.Size(120, 32)
        Me.btnP1Next.TabIndex = 0
        Me.btnP1Next.Text = "Next"
        Me.btnP1Next.UseVisualStyleBackColor = True
        Me.btnP1Next.UseWaitCursor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.BtnRemVeh)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.TxtQty)
        Me.TabPage2.Controls.Add(Me.CmbVeh)
        Me.TabPage2.Controls.Add(Me.BtnDelVeh)
        Me.TabPage2.Controls.Add(Me.BtnAddVeh)
        Me.TabPage2.Controls.Add(Me.LBVeh)
        Me.TabPage2.Controls.Add(Me.ChkSpecNote)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.ChkIncIA)
        Me.TabPage2.Controls.Add(Me.ChkExcTMF)
        Me.TabPage2.Controls.Add(Me.ChkExcPIA)
        Me.TabPage2.Controls.Add(Me.ChkIncPO)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.ChkLvl2)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.cmbAssemIA)
        Me.TabPage2.Controls.Add(Me.gbReportType)
        Me.TabPage2.Controls.Add(Me.btnSpecAssem)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.btnP2Back)
        Me.TabPage2.Controls.Add(Me.btnP2Cancel)
        Me.TabPage2.Controls.Add(Me.btnP2Next)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1185, 677)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Select Vehicle & Quantity"
        Me.TabPage2.UseVisualStyleBackColor = True
        Me.TabPage2.UseWaitCursor = True
        '
        'BtnRemVeh
        '
        Me.BtnRemVeh.Location = New System.Drawing.Point(122, 508)
        Me.BtnRemVeh.Name = "BtnRemVeh"
        Me.BtnRemVeh.Size = New System.Drawing.Size(102, 33)
        Me.BtnRemVeh.TabIndex = 48
        Me.BtnRemVeh.Text = "Delete Veh"
        Me.BtnRemVeh.UseVisualStyleBackColor = True
        Me.BtnRemVeh.UseWaitCursor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(441, 193)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 17)
        Me.Label8.TabIndex = 47
        Me.Label8.Text = "Qty"
        Me.Label8.UseWaitCursor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(206, 193)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(97, 17)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Select Vehicle"
        Me.Label5.UseWaitCursor = True
        '
        'TxtQty
        '
        Me.TxtQty.Location = New System.Drawing.Point(417, 213)
        Me.TxtQty.Name = "TxtQty"
        Me.TxtQty.Size = New System.Drawing.Size(74, 22)
        Me.TxtQty.TabIndex = 45
        Me.TxtQty.UseWaitCursor = True
        '
        'CmbVeh
        '
        Me.CmbVeh.FormattingEnabled = True
        Me.CmbVeh.Location = New System.Drawing.Point(102, 213)
        Me.CmbVeh.Name = "CmbVeh"
        Me.CmbVeh.Size = New System.Drawing.Size(298, 24)
        Me.CmbVeh.TabIndex = 44
        Me.CmbVeh.UseWaitCursor = True
        '
        'BtnDelVeh
        '
        Me.BtnDelVeh.Location = New System.Drawing.Point(369, 508)
        Me.BtnDelVeh.Name = "BtnDelVeh"
        Me.BtnDelVeh.Size = New System.Drawing.Size(102, 33)
        Me.BtnDelVeh.TabIndex = 43
        Me.BtnDelVeh.Text = "Clear List"
        Me.BtnDelVeh.UseVisualStyleBackColor = True
        Me.BtnDelVeh.UseWaitCursor = True
        '
        'BtnAddVeh
        '
        Me.BtnAddVeh.Location = New System.Drawing.Point(497, 208)
        Me.BtnAddVeh.Name = "BtnAddVeh"
        Me.BtnAddVeh.Size = New System.Drawing.Size(79, 33)
        Me.BtnAddVeh.TabIndex = 42
        Me.BtnAddVeh.Text = "Add Veh."
        Me.BtnAddVeh.UseVisualStyleBackColor = True
        Me.BtnAddVeh.UseWaitCursor = True
        '
        'LBVeh
        '
        Me.LBVeh.FormattingEnabled = True
        Me.LBVeh.ItemHeight = 16
        Me.LBVeh.Location = New System.Drawing.Point(102, 258)
        Me.LBVeh.Name = "LBVeh"
        Me.LBVeh.Size = New System.Drawing.Size(389, 244)
        Me.LBVeh.TabIndex = 41
        Me.LBVeh.UseWaitCursor = True
        '
        'ChkSpecNote
        '
        Me.ChkSpecNote.AutoSize = True
        Me.ChkSpecNote.Location = New System.Drawing.Point(680, 481)
        Me.ChkSpecNote.Name = "ChkSpecNote"
        Me.ChkSpecNote.Size = New System.Drawing.Size(166, 21)
        Me.ChkSpecNote.TabIndex = 40
        Me.ChkSpecNote.Text = "Include Special Notes"
        Me.ChkSpecNote.UseVisualStyleBackColor = True
        Me.ChkSpecNote.UseWaitCursor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(98, 87)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(420, 40)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Select the vehicles and their qty for the report. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Vehicles with a quantity of 0" &
    " will not be included."
        Me.Label1.UseWaitCursor = True
        '
        'ChkIncIA
        '
        Me.ChkIncIA.AutoSize = True
        Me.ChkIncIA.Checked = True
        Me.ChkIncIA.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkIncIA.Location = New System.Drawing.Point(680, 400)
        Me.ChkIncIA.Name = "ChkIncIA"
        Me.ChkIncIA.Size = New System.Drawing.Size(98, 21)
        Me.ChkIncIA.TabIndex = 30
        Me.ChkIncIA.Text = "Include IAs"
        Me.ChkIncIA.UseVisualStyleBackColor = True
        Me.ChkIncIA.UseWaitCursor = True
        '
        'ChkExcTMF
        '
        Me.ChkExcTMF.AutoSize = True
        Me.ChkExcTMF.Checked = True
        Me.ChkExcTMF.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkExcTMF.Location = New System.Drawing.Point(680, 454)
        Me.ChkExcTMF.Name = "ChkExcTMF"
        Me.ChkExcTMF.Size = New System.Drawing.Size(225, 21)
        Me.ChkExcTMF.TabIndex = 29
        Me.ChkExcTMF.Text = "Exclude non Triad Make Froms"
        Me.ChkExcTMF.UseVisualStyleBackColor = True
        Me.ChkExcTMF.UseWaitCursor = True
        '
        'ChkExcPIA
        '
        Me.ChkExcPIA.AutoSize = True
        Me.ChkExcPIA.Checked = True
        Me.ChkExcPIA.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkExcPIA.Location = New System.Drawing.Point(680, 427)
        Me.ChkExcPIA.Name = "ChkExcPIA"
        Me.ChkExcPIA.Size = New System.Drawing.Size(141, 21)
        Me.ChkExcPIA.TabIndex = 28
        Me.ChkExcPIA.Text = "Exclude PIA Items"
        Me.ChkExcPIA.UseVisualStyleBackColor = True
        Me.ChkExcPIA.UseWaitCursor = True
        '
        'ChkIncPO
        '
        Me.ChkIncPO.AutoSize = True
        Me.ChkIncPO.Checked = True
        Me.ChkIncPO.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkIncPO.Location = New System.Drawing.Point(680, 373)
        Me.ChkIncPO.Name = "ChkIncPO"
        Me.ChkIncPO.Size = New System.Drawing.Size(176, 21)
        Me.ChkIncPO.TabIndex = 27
        Me.ChkIncPO.Text = "Include Product Orders"
        Me.ChkIncPO.UseVisualStyleBackColor = True
        Me.ChkIncPO.UseWaitCursor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(675, 313)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(258, 25)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Additional Report Options"
        Me.Label6.UseWaitCursor = True
        '
        'ChkLvl2
        '
        Me.ChkLvl2.AutoSize = True
        Me.ChkLvl2.Location = New System.Drawing.Point(680, 346)
        Me.ChkLvl2.Name = "ChkLvl2"
        Me.ChkLvl2.Size = New System.Drawing.Size(146, 21)
        Me.ChkLvl2.TabIndex = 25
        Me.ChkLvl2.Text = "Level 2 Parts Only"
        Me.ChkLvl2.UseVisualStyleBackColor = True
        Me.ChkLvl2.UseWaitCursor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(676, 228)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(254, 17)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Please select an assembly/IA to Report"
        Me.Label7.UseWaitCursor = True
        Me.Label7.Visible = False
        '
        'cmbAssemIA
        '
        Me.cmbAssemIA.FormattingEnabled = True
        Me.cmbAssemIA.Location = New System.Drawing.Point(679, 248)
        Me.cmbAssemIA.Name = "cmbAssemIA"
        Me.cmbAssemIA.Size = New System.Drawing.Size(377, 24)
        Me.cmbAssemIA.TabIndex = 23
        Me.cmbAssemIA.UseWaitCursor = True
        Me.cmbAssemIA.Visible = False
        '
        'gbReportType
        '
        Me.gbReportType.Controls.Add(Me.RadioButton12)
        Me.gbReportType.Controls.Add(Me.RadioButton13)
        Me.gbReportType.Location = New System.Drawing.Point(679, 118)
        Me.gbReportType.Name = "gbReportType"
        Me.gbReportType.Size = New System.Drawing.Size(254, 100)
        Me.gbReportType.TabIndex = 22
        Me.gbReportType.TabStop = False
        Me.gbReportType.Text = "Select Report Type"
        Me.gbReportType.UseWaitCursor = True
        Me.gbReportType.Visible = False
        '
        'RadioButton12
        '
        Me.RadioButton12.AutoSize = True
        Me.RadioButton12.Location = New System.Drawing.Point(24, 59)
        Me.RadioButton12.Name = "RadioButton12"
        Me.RadioButton12.Size = New System.Drawing.Size(162, 21)
        Me.RadioButton12.TabIndex = 1
        Me.RadioButton12.TabStop = True
        Me.RadioButton12.Text = "Report for Specific IA"
        Me.RadioButton12.UseVisualStyleBackColor = True
        Me.RadioButton12.UseWaitCursor = True
        '
        'RadioButton13
        '
        Me.RadioButton13.AutoSize = True
        Me.RadioButton13.Location = New System.Drawing.Point(24, 32)
        Me.RadioButton13.Name = "RadioButton13"
        Me.RadioButton13.Size = New System.Drawing.Size(210, 21)
        Me.RadioButton13.TabIndex = 0
        Me.RadioButton13.TabStop = True
        Me.RadioButton13.Text = "Report for Specific Assembly"
        Me.RadioButton13.UseVisualStyleBackColor = True
        Me.RadioButton13.UseWaitCursor = True
        '
        'btnSpecAssem
        '
        Me.btnSpecAssem.Location = New System.Drawing.Point(679, 51)
        Me.btnSpecAssem.Name = "btnSpecAssem"
        Me.btnSpecAssem.Size = New System.Drawing.Size(377, 36)
        Me.btnSpecAssem.TabIndex = 21
        Me.btnSpecAssem.Text = "Change to Report for Specific Assembly or Specific IA"
        Me.btnSpecAssem.UseVisualStyleBackColor = True
        Me.btnSpecAssem.UseWaitCursor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft New Tai Lue", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(63, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(600, 44)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Step 2 of 4 - Enter Vehicle Quantity"
        Me.Label2.UseWaitCursor = True
        '
        'btnP2Back
        '
        Me.btnP2Back.Location = New System.Drawing.Point(860, 617)
        Me.btnP2Back.Name = "btnP2Back"
        Me.btnP2Back.Size = New System.Drawing.Size(120, 32)
        Me.btnP2Back.TabIndex = 2
        Me.btnP2Back.Text = "Back"
        Me.btnP2Back.UseVisualStyleBackColor = True
        Me.btnP2Back.UseWaitCursor = True
        '
        'btnP2Cancel
        '
        Me.btnP2Cancel.Location = New System.Drawing.Point(46, 617)
        Me.btnP2Cancel.Name = "btnP2Cancel"
        Me.btnP2Cancel.Size = New System.Drawing.Size(120, 32)
        Me.btnP2Cancel.TabIndex = 1
        Me.btnP2Cancel.Text = "Close"
        Me.btnP2Cancel.UseVisualStyleBackColor = True
        Me.btnP2Cancel.UseWaitCursor = True
        '
        'btnP2Next
        '
        Me.btnP2Next.Location = New System.Drawing.Point(1019, 617)
        Me.btnP2Next.Name = "btnP2Next"
        Me.btnP2Next.Size = New System.Drawing.Size(120, 32)
        Me.btnP2Next.TabIndex = 0
        Me.btnP2Next.Text = "Next"
        Me.btnP2Next.UseVisualStyleBackColor = True
        Me.btnP2Next.UseWaitCursor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.CheckedListBox1)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Controls.Add(Me.GroupBox9)
        Me.TabPage3.Controls.Add(Me.ListBox1)
        Me.TabPage3.Controls.Add(Me.GroupBox10)
        Me.TabPage3.Controls.Add(Me.GroupBox11)
        Me.TabPage3.Controls.Add(Me.GroupBox12)
        Me.TabPage3.Controls.Add(Me.GroupBox8)
        Me.TabPage3.Controls.Add(Me.ListBox2)
        Me.TabPage3.Controls.Add(Me.GroupBox7)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.btnP3Back)
        Me.TabPage3.Controls.Add(Me.btnP3Cancel)
        Me.TabPage3.Controls.Add(Me.btnP3Next)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1185, 677)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Report Options & Filters"
        Me.TabPage3.UseVisualStyleBackColor = True
        Me.TabPage3.UseWaitCursor = True
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"Open", "Closed", "Cancelled"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(869, 387)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(246, 89)
        Me.CheckedListBox1.TabIndex = 24
        Me.CheckedListBox1.UseWaitCursor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton3)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(869, 113)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(246, 125)
        Me.GroupBox1.TabIndex = 23
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Component Types"
        Me.GroupBox1.UseWaitCursor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(23, 90)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(171, 21)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "All (Final + Make-from)"
        Me.RadioButton3.UseVisualStyleBackColor = True
        Me.RadioButton3.UseWaitCursor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(23, 63)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(212, 21)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Make-from Components Only"
        Me.RadioButton2.UseVisualStyleBackColor = True
        Me.RadioButton2.UseWaitCursor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(23, 36)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(141, 21)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Components Only"
        Me.RadioButton1.UseVisualStyleBackColor = True
        Me.RadioButton1.UseWaitCursor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.RadioButton23)
        Me.GroupBox9.Controls.Add(Me.RadioButton24)
        Me.GroupBox9.Controls.Add(Me.RadioButton25)
        Me.GroupBox9.Location = New System.Drawing.Point(73, 431)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(200, 121)
        Me.GroupBox9.TabIndex = 22
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Station Tabs"
        Me.GroupBox9.UseWaitCursor = True
        '
        'RadioButton23
        '
        Me.RadioButton23.AutoSize = True
        Me.RadioButton23.Location = New System.Drawing.Point(23, 84)
        Me.RadioButton23.Name = "RadioButton23"
        Me.RadioButton23.Size = New System.Drawing.Size(110, 21)
        Me.RadioButton23.TabIndex = 2
        Me.RadioButton23.TabStop = True
        Me.RadioButton23.Text = "Indented List"
        Me.RadioButton23.UseVisualStyleBackColor = True
        Me.RadioButton23.UseWaitCursor = True
        '
        'RadioButton24
        '
        Me.RadioButton24.AutoSize = True
        Me.RadioButton24.Location = New System.Drawing.Point(23, 57)
        Me.RadioButton24.Name = "RadioButton24"
        Me.RadioButton24.Size = New System.Drawing.Size(78, 21)
        Me.RadioButton24.TabIndex = 1
        Me.RadioButton24.TabStop = True
        Me.RadioButton24.Text = "Flat List"
        Me.RadioButton24.UseVisualStyleBackColor = True
        Me.RadioButton24.UseWaitCursor = True
        '
        'RadioButton25
        '
        Me.RadioButton25.AutoSize = True
        Me.RadioButton25.Location = New System.Drawing.Point(23, 30)
        Me.RadioButton25.Name = "RadioButton25"
        Me.RadioButton25.Size = New System.Drawing.Size(63, 21)
        Me.RadioButton25.TabIndex = 0
        Me.RadioButton25.TabStop = True
        Me.RadioButton25.Text = "None"
        Me.RadioButton25.UseVisualStyleBackColor = True
        Me.RadioButton25.UseWaitCursor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(307, 255)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox1.Size = New System.Drawing.Size(200, 340)
        Me.ListBox1.TabIndex = 15
        Me.ListBox1.UseWaitCursor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.RadioButton26)
        Me.GroupBox10.Controls.Add(Me.RadioButton27)
        Me.GroupBox10.Location = New System.Drawing.Point(73, 325)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox10.TabIndex = 21
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Demand Calculation Type"
        Me.GroupBox10.UseWaitCursor = True
        '
        'RadioButton26
        '
        Me.RadioButton26.AutoSize = True
        Me.RadioButton26.Location = New System.Drawing.Point(23, 62)
        Me.RadioButton26.Name = "RadioButton26"
        Me.RadioButton26.Size = New System.Drawing.Size(103, 21)
        Me.RadioButton26.TabIndex = 1
        Me.RadioButton26.TabStop = True
        Me.RadioButton26.Text = "Ignore PO's"
        Me.RadioButton26.UseVisualStyleBackColor = True
        Me.RadioButton26.UseWaitCursor = True
        '
        'RadioButton27
        '
        Me.RadioButton27.AutoSize = True
        Me.RadioButton27.Location = New System.Drawing.Point(23, 35)
        Me.RadioButton27.Name = "RadioButton27"
        Me.RadioButton27.Size = New System.Drawing.Size(108, 21)
        Me.RadioButton27.TabIndex = 0
        Me.RadioButton27.TabStop = True
        Me.RadioButton27.Text = "Include PO's"
        Me.RadioButton27.UseVisualStyleBackColor = True
        Me.RadioButton27.UseWaitCursor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.RadioButton28)
        Me.GroupBox11.Controls.Add(Me.RadioButton29)
        Me.GroupBox11.Location = New System.Drawing.Point(73, 219)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox11.TabIndex = 20
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Select BOM Type"
        Me.GroupBox11.UseWaitCursor = True
        '
        'RadioButton28
        '
        Me.RadioButton28.AutoSize = True
        Me.RadioButton28.Location = New System.Drawing.Point(19, 60)
        Me.RadioButton28.Name = "RadioButton28"
        Me.RadioButton28.Size = New System.Drawing.Size(166, 21)
        Me.RadioButton28.TabIndex = 1
        Me.RadioButton28.TabStop = True
        Me.RadioButton28.Text = "Build Readiness BOM"
        Me.RadioButton28.UseVisualStyleBackColor = True
        Me.RadioButton28.UseWaitCursor = True
        '
        'RadioButton29
        '
        Me.RadioButton29.AutoSize = True
        Me.RadioButton29.Location = New System.Drawing.Point(19, 33)
        Me.RadioButton29.Name = "RadioButton29"
        Me.RadioButton29.Size = New System.Drawing.Size(119, 21)
        Me.RadioButton29.TabIndex = 0
        Me.RadioButton29.TabStop = True
        Me.RadioButton29.Text = "Indented BOM"
        Me.RadioButton29.UseVisualStyleBackColor = True
        Me.RadioButton29.UseWaitCursor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.RadioButton30)
        Me.GroupBox12.Controls.Add(Me.RadioButton31)
        Me.GroupBox12.Location = New System.Drawing.Point(73, 113)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox12.TabIndex = 19
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Format Type"
        Me.GroupBox12.UseWaitCursor = True
        '
        'RadioButton30
        '
        Me.RadioButton30.AutoSize = True
        Me.RadioButton30.Location = New System.Drawing.Point(18, 59)
        Me.RadioButton30.Name = "RadioButton30"
        Me.RadioButton30.Size = New System.Drawing.Size(136, 21)
        Me.RadioButton30.TabIndex = 1
        Me.RadioButton30.TabStop = True
        Me.RadioButton30.Text = "IA-Manufacturing"
        Me.RadioButton30.UseVisualStyleBackColor = True
        Me.RadioButton30.UseWaitCursor = True
        '
        'RadioButton31
        '
        Me.RadioButton31.AutoSize = True
        Me.RadioButton31.Location = New System.Drawing.Point(18, 32)
        Me.RadioButton31.Name = "RadioButton31"
        Me.RadioButton31.Size = New System.Drawing.Size(68, 21)
        Me.RadioButton31.TabIndex = 0
        Me.RadioButton31.Text = "IA-Full"
        Me.RadioButton31.UseVisualStyleBackColor = True
        Me.RadioButton31.UseWaitCursor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.RadioButton4)
        Me.GroupBox8.Controls.Add(Me.RadioButton22)
        Me.GroupBox8.Controls.Add(Me.RadioButton18)
        Me.GroupBox8.Location = New System.Drawing.Point(869, 256)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(246, 125)
        Me.GroupBox8.TabIndex = 18
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Select PR/PO/SWO Status"
        Me.GroupBox8.UseWaitCursor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(27, 61)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(130, 21)
        Me.RadioButton4.TabIndex = 5
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Select From List"
        Me.RadioButton4.UseVisualStyleBackColor = True
        Me.RadioButton4.UseWaitCursor = True
        '
        'RadioButton22
        '
        Me.RadioButton22.AutoSize = True
        Me.RadioButton22.Location = New System.Drawing.Point(27, 88)
        Me.RadioButton22.Name = "RadioButton22"
        Me.RadioButton22.Size = New System.Drawing.Size(63, 21)
        Me.RadioButton22.TabIndex = 4
        Me.RadioButton22.TabStop = True
        Me.RadioButton22.Text = "None"
        Me.RadioButton22.UseVisualStyleBackColor = True
        Me.RadioButton22.UseWaitCursor = True
        '
        'RadioButton18
        '
        Me.RadioButton18.AutoSize = True
        Me.RadioButton18.Location = New System.Drawing.Point(27, 34)
        Me.RadioButton18.Name = "RadioButton18"
        Me.RadioButton18.Size = New System.Drawing.Size(44, 21)
        Me.RadioButton18.TabIndex = 0
        Me.RadioButton18.TabStop = True
        Me.RadioButton18.Text = "All"
        Me.RadioButton18.UseVisualStyleBackColor = True
        Me.RadioButton18.UseWaitCursor = True
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 16
        Me.ListBox2.Location = New System.Drawing.Point(522, 255)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox2.Size = New System.Drawing.Size(318, 340)
        Me.ListBox2.TabIndex = 17
        Me.ListBox2.UseWaitCursor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.RadioButton17)
        Me.GroupBox7.Controls.Add(Me.RadioButton16)
        Me.GroupBox7.Controls.Add(Me.RadioButton15)
        Me.GroupBox7.Location = New System.Drawing.Point(522, 113)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(318, 125)
        Me.GroupBox7.TabIndex = 16
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "PR/PO/SWO Job Number(s)"
        Me.GroupBox7.UseWaitCursor = True
        '
        'RadioButton17
        '
        Me.RadioButton17.AutoSize = True
        Me.RadioButton17.Location = New System.Drawing.Point(35, 85)
        Me.RadioButton17.Name = "RadioButton17"
        Me.RadioButton17.Size = New System.Drawing.Size(156, 21)
        Me.RadioButton17.TabIndex = 2
        Me.RadioButton17.TabStop = True
        Me.RadioButton17.Text = "Select Job Numbers"
        Me.RadioButton17.UseVisualStyleBackColor = True
        Me.RadioButton17.UseWaitCursor = True
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.Location = New System.Drawing.Point(35, 58)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(132, 21)
        Me.RadioButton16.TabIndex = 1
        Me.RadioButton16.TabStop = True
        Me.RadioButton16.Text = "All Job Numbers"
        Me.RadioButton16.UseVisualStyleBackColor = True
        Me.RadioButton16.UseWaitCursor = True
        '
        'RadioButton15
        '
        Me.RadioButton15.AutoSize = True
        Me.RadioButton15.Location = New System.Drawing.Point(35, 31)
        Me.RadioButton15.Name = "RadioButton15"
        Me.RadioButton15.Size = New System.Drawing.Size(188, 21)
        Me.RadioButton15.TabIndex = 0
        Me.RadioButton15.TabStop = True
        Me.RadioButton15.Text = "Active Job Numbers Only"
        Me.RadioButton15.UseVisualStyleBackColor = True
        Me.RadioButton15.UseWaitCursor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.RadioButton14)
        Me.GroupBox5.Controls.Add(Me.RadioButton11)
        Me.GroupBox5.Controls.Add(Me.RadioButton10)
        Me.GroupBox5.Location = New System.Drawing.Point(307, 113)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 125)
        Me.GroupBox5.TabIndex = 14
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Inventory Groups"
        Me.GroupBox5.UseWaitCursor = True
        '
        'RadioButton14
        '
        Me.RadioButton14.AutoSize = True
        Me.RadioButton14.Location = New System.Drawing.Point(31, 58)
        Me.RadioButton14.Name = "RadioButton14"
        Me.RadioButton14.Size = New System.Drawing.Size(63, 21)
        Me.RadioButton14.TabIndex = 2
        Me.RadioButton14.TabStop = True
        Me.RadioButton14.Text = "None"
        Me.RadioButton14.UseVisualStyleBackColor = True
        Me.RadioButton14.UseWaitCursor = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Location = New System.Drawing.Point(31, 85)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(130, 21)
        Me.RadioButton11.TabIndex = 1
        Me.RadioButton11.TabStop = True
        Me.RadioButton11.Text = "Select From List"
        Me.RadioButton11.UseVisualStyleBackColor = True
        Me.RadioButton11.UseWaitCursor = True
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Location = New System.Drawing.Point(31, 31)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(44, 21)
        Me.RadioButton10.TabIndex = 0
        Me.RadioButton10.TabStop = True
        Me.RadioButton10.Text = "All"
        Me.RadioButton10.UseVisualStyleBackColor = True
        Me.RadioButton10.UseWaitCursor = True
        '
        'btnP3Back
        '
        Me.btnP3Back.Location = New System.Drawing.Point(860, 617)
        Me.btnP3Back.Name = "btnP3Back"
        Me.btnP3Back.Size = New System.Drawing.Size(120, 32)
        Me.btnP3Back.TabIndex = 13
        Me.btnP3Back.Text = "Back"
        Me.btnP3Back.UseVisualStyleBackColor = True
        Me.btnP3Back.UseWaitCursor = True
        '
        'btnP3Cancel
        '
        Me.btnP3Cancel.Location = New System.Drawing.Point(46, 617)
        Me.btnP3Cancel.Name = "btnP3Cancel"
        Me.btnP3Cancel.Size = New System.Drawing.Size(120, 32)
        Me.btnP3Cancel.TabIndex = 12
        Me.btnP3Cancel.Text = "Close"
        Me.btnP3Cancel.UseVisualStyleBackColor = True
        Me.btnP3Cancel.UseWaitCursor = True
        '
        'btnP3Next
        '
        Me.btnP3Next.Location = New System.Drawing.Point(1019, 617)
        Me.btnP3Next.Name = "btnP3Next"
        Me.btnP3Next.Size = New System.Drawing.Size(120, 32)
        Me.btnP3Next.TabIndex = 11
        Me.btnP3Next.Text = "Next"
        Me.btnP3Next.UseVisualStyleBackColor = True
        Me.btnP3Next.UseWaitCursor = True
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft New Tai Lue", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label3.Location = New System.Drawing.Point(63, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(603, 44)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Step 3 of 4 - Report Options / Filters"
        Me.Label3.UseWaitCursor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Barlbl)
        Me.TabPage4.Controls.Add(Me.ProgressBar1)
        Me.TabPage4.Controls.Add(Me.RichTextBox1)
        Me.TabPage4.Controls.Add(Me.btnFinal)
        Me.TabPage4.Controls.Add(Me.btnP4Back)
        Me.TabPage4.Controls.Add(Me.btnP4Cancel)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1185, 677)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Review & Run Report"
        Me.TabPage4.UseVisualStyleBackColor = True
        Me.TabPage4.UseWaitCursor = True
        '
        'Barlbl
        '
        Me.Barlbl.AutoSize = True
        Me.Barlbl.Location = New System.Drawing.Point(495, 579)
        Me.Barlbl.Name = "Barlbl"
        Me.Barlbl.Size = New System.Drawing.Size(23, 17)
        Me.Barlbl.TabIndex = 20
        Me.Barlbl.Text = "---"
        Me.Barlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Barlbl.UseWaitCursor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(498, 553)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(210, 23)
        Me.ProgressBar1.TabIndex = 19
        Me.ProgressBar1.UseWaitCursor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(46, 90)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1079, 403)
        Me.RichTextBox1.TabIndex = 18
        Me.RichTextBox1.Text = ""
        Me.RichTextBox1.UseWaitCursor = True
        '
        'btnFinal
        '
        Me.btnFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFinal.Location = New System.Drawing.Point(545, 499)
        Me.btnFinal.Name = "btnFinal"
        Me.btnFinal.Size = New System.Drawing.Size(120, 32)
        Me.btnFinal.TabIndex = 17
        Me.btnFinal.Text = "Run Report"
        Me.btnFinal.UseVisualStyleBackColor = True
        Me.btnFinal.UseWaitCursor = True
        '
        'btnP4Back
        '
        Me.btnP4Back.Location = New System.Drawing.Point(860, 617)
        Me.btnP4Back.Name = "btnP4Back"
        Me.btnP4Back.Size = New System.Drawing.Size(120, 32)
        Me.btnP4Back.TabIndex = 15
        Me.btnP4Back.Text = "Back"
        Me.btnP4Back.UseVisualStyleBackColor = True
        Me.btnP4Back.UseWaitCursor = True
        '
        'btnP4Cancel
        '
        Me.btnP4Cancel.Location = New System.Drawing.Point(46, 617)
        Me.btnP4Cancel.Name = "btnP4Cancel"
        Me.btnP4Cancel.Size = New System.Drawing.Size(120, 32)
        Me.btnP4Cancel.TabIndex = 14
        Me.btnP4Cancel.Text = "Close"
        Me.btnP4Cancel.UseVisualStyleBackColor = True
        Me.btnP4Cancel.UseWaitCursor = True
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft New Tai Lue", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label4.Location = New System.Drawing.Point(63, 43)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(602, 44)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Step 4 of 4 - Review / Run Report"
        Me.Label4.UseWaitCursor = True
        '
        'BomReportUseQty
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1217, 730)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "BomReportUseQty"
        Me.Text = "BOM Reports"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.gbReportType.ResumeLayout(False)
        Me.gbReportType.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents btnP1Cancel As Button
    Friend WithEvents btnP1Next As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents LblStart As Label
    Friend WithEvents LblStep1 As Label
    Friend WithEvents btnP2Back As Button
    Friend WithEvents btnP2Cancel As Button
    Friend WithEvents btnP2Next As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents ChkIncIA As CheckBox
    Friend WithEvents ChkExcTMF As CheckBox
    Friend WithEvents ChkExcPIA As CheckBox
    Friend WithEvents ChkIncPO As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ChkLvl2 As CheckBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbAssemIA As ComboBox
    Friend WithEvents gbReportType As GroupBox
    Friend WithEvents RadioButton12 As RadioButton
    Friend WithEvents RadioButton13 As RadioButton
    Friend WithEvents btnSpecAssem As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents btnP3Back As Button
    Friend WithEvents btnP3Cancel As Button
    Friend WithEvents btnP3Next As Button
    Friend WithEvents RadioButton14 As RadioButton
    Friend WithEvents RadioButton11 As RadioButton
    Friend WithEvents RadioButton10 As RadioButton
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents RadioButton23 As RadioButton
    Friend WithEvents RadioButton24 As RadioButton
    Friend WithEvents RadioButton25 As RadioButton
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents RadioButton26 As RadioButton
    Friend WithEvents RadioButton27 As RadioButton
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents RadioButton28 As RadioButton
    Friend WithEvents RadioButton29 As RadioButton
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents RadioButton30 As RadioButton
    Friend WithEvents RadioButton31 As RadioButton
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents RadioButton22 As RadioButton
    Friend WithEvents RadioButton18 As RadioButton
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents RadioButton17 As RadioButton
    Friend WithEvents RadioButton16 As RadioButton
    Friend WithEvents RadioButton15 As RadioButton
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnP4Back As Button
    Friend WithEvents btnP4Cancel As Button
    Friend WithEvents btnFinal As Button
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ChkSpecNote As CheckBox
    Friend WithEvents TxtQty As TextBox
    Friend WithEvents CmbVeh As ComboBox
    Friend WithEvents BtnDelVeh As Button
    Friend WithEvents BtnAddVeh As Button
    Friend WithEvents LBVeh As ListBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Barlbl As Label
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents BtnRemVeh As Button
End Class
