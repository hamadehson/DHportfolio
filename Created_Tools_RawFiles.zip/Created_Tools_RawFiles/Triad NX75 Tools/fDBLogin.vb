﻿Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings
Imports System.Data.SqlClient

Public Class FDBLogin

    Public Testconn As SqlConnection
    Public Shared Dbstring As String
    Public Shared UserString As String
    Public Shared PassString As String

    Private Sub FDBLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim conn = New SqlConnection("Server=databasesvr3;DataBase=Chieftain;User Id=dhamadeh;Password=dan12345")

        Dim SelStmt As String
        SelStmt = "Select ProjectName from TriadSecurity.dbo.Projects where ActiveApp = 1 Order by ProjectName"
        Dim cmd As New SqlCommand(SelStmt, conn)
        Dim DA As New SqlDataAdapter(cmd)
        Dim DT As New DataTable("ProjectName")
        DA.Fill(DT)
        ListBoxDB.DataSource = DT
        ListBoxDB.DisplayMember = "ProjectName"
        ListBoxDB.ValueMember = "ProjectName"

    End Sub


    Private Sub BtnConn_Click(sender As Object, e As EventArgs) Handles BtnConn.Click

        Dbstring = ListBoxDB.GetItemText(ListBoxDB.SelectedItem)
        If Dbstring = "Land Cruiser" Then
            Dbstring = "Landcruiser"
        ElseIf Dbstring = "4 Runner" Then
            Dbstring = "fourrunner"
        End If

        UserString = txtLogin.Text
        PassString = txtPass.Text
        Testconn = New SqlConnection("Server=databasesvr3;DataBase=" & Dbstring & ";User Id=" & UserString & ";Password=" & PassString & "")

        Try
            Testconn.Open()
        Catch
            Testconn.Close()
        End Try

        If (Testconn.State = ConnectionState.Open) Then
            Dim f1 As New BomReportUseQty
            f1.ShowDialog()
            Testconn.Close()
            Close()
        Else
            MessageBox.Show("Your Username and/or password are incorrect.")
            txtPass.Select()
        End If

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Close()
    End Sub

    Private Sub ListBoxDB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxDB.SelectedIndexChanged
        Label3.Text = ListBoxDB.GetItemText(ListBoxDB.SelectedItem)
    End Sub
End Class