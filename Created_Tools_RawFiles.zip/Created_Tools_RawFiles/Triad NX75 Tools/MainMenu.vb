﻿Public Class MainMenu


    Private Sub MainMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


    Private Sub btnGMAttributes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGMAttributes.Click
        Me.Dispose()
        Dim f1 As New GM_Attrib_Startup
        f1.ShowDialog()
    End Sub

    Private Sub btnCreatePDF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreatePDF.Click
        Me.Dispose()
        Dim f1 As New PDF_Startup
        f1.ShowDialog()
    End Sub

    Private Sub btnDwgModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDwgModel.Click
        Me.Dispose()
        Dim f1 As New DWG_Model_Startup
        f1.ShowDialog()
    End Sub

    Private Sub btnCreateXT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateXT.Click
        Me.Dispose()
        Dim f1 As New XT_Startup
        f1.ShowDialog()
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        Application.Exit()
    End Sub

    Private Sub btnSTEP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSTEP.Click
        Me.Dispose()
        Dim f1 As New STEP_Startup
        f1.ShowDialog()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim f1 As New frmAbout
        f1.ShowDialog()
    End Sub

    Private Sub btnWarningNote_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWarningNote.Click
        Me.Dispose()
        Dim f1 As New Warning_Note_Form1
        f1.ShowDialog()
    End Sub

    Private Sub btnClearAttributes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAttributes.Click
        Me.Dispose()
        Dim f1 As New Clear_Attributes_Startup
        f1.ShowDialog()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Dispose()
        Dim f1 As New Chieftain_Attrib_Startup
        f1.ShowDialog()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Dispose()
        Dim f1 As New Finder
        f1.ShowDialog()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IPAImport.Click
        Me.Dispose()
        Dim f1 As New ImportIPA
        f1.ShowDialog()
    End Sub

    Private Sub btnCopyFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyFiles.Click
        Me.Dispose()
        Dim f1 As New Move_File_List
        f1.ShowDialog()
    End Sub

    Private Sub btnBMP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBMP.Click
        Me.Dispose()
        Dim f1 As New bmp_Startup
        f1.ShowDialog()
    End Sub

    Private Sub ButtonFileCleanUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonFileCleanUp.Click
        Dim f1 As New FileCleanUp
        f1.ShowDialog()
    End Sub

    Private Sub btnPartRet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPartRet.Click
        Dim f1 As New PartRet_Form
        f1.ShowDialog()
    End Sub


    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        Dim f1 As New FDBLogin
        f1.ShowDialog()
    End Sub
End Class