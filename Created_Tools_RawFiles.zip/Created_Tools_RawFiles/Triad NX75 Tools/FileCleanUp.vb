﻿Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings
Imports System.Data.SqlClient


Public Class FileCleanUp

    Dim drs As String()

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox2.Text = Get_Directory()
    End Sub

    Private Sub btnDirectory_Click(sender As Object, e As EventArgs) Handles btnDirectory.Click

        If TextBox2.Text = "" Then
            MsgBox("Please select the directory to be searched", MsgBoxStyle.OkOnly, "Unselected Directory")
        Else
            ''''get list of files in the dir
            drs = Directory.GetFiles(TextBox2.Text, "5478*")

            Dim FilePartNum As String
            Dim FileRev As String
            Dim FileRevType As String
            Dim FileType As String
            Dim Check As ADODB.Recordset
            Dim CurDate As String
            Dim DestFile As String
            Dim cmd As New SqlCommand
            Dim ds As SqlDataReader


            Dim conn = New SqlConnection("Server=databasesvr3;DataBase=Chieftain;User Id=dhamadeh;Password=dan12345")

            CurDate = String.Format("{0:dd/MM/yyyy}", DateTime.Now)

            For Each fcheck In drs

                '''' Test Folder ---------------------------------------------
                ''''FilePartNum = mvs.Mid(fcheck, 40, 8)
                ''''FileRevType = mvs.Mid(fcheck, 49, 4)
                ''''FileRev = mvs.Mid(fcheck, 53, 4)
                ''''FileType = mvs.Right(fcheck, 3)
                '''' Test Folder ---------------------------------------------

                FileRevType = mvs.Mid(fcheck, 57, 2)

                If FileRevType = "ia" Then
                    FilePartNum = mvs.Mid(fcheck, 48, 8)
                    FileRev = mvs.Mid(fcheck, 60, 4)
                    FileType = mvs.Right(fcheck, 3)
                Else

                    FileRevType = mvs.Mid(fcheck, 57, 3)

                    If FileRevType = "dwg" Or FileRevType = "asm" Or FileRevType = "mdl" Then
                        FilePartNum = mvs.Mid(fcheck, 48, 8)
                        FileRev = mvs.Mid(fcheck, 61, 4)
                        FileType = mvs.Right(fcheck, 3)
                    Else
                        FileRevType = mvs.Mid(fcheck, 57, 4)
                        FilePartNum = mvs.Mid(fcheck, 48, 8)
                        FileRev = mvs.Mid(fcheck, 62, 4)
                        FileType = mvs.Right(fcheck, 3)
                    End If

                End If


                DestFile = "\\DESIGNSVR2\Designdata\Chieftain\Archive_Data\" & FilePartNum & "." & FileRevType & "." & FileRev & "." & FileType

                If FileRevType = "dwg" Or FileRevType = "edwg" Or FileRevType = "ia" Then

                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "getCleanUpFiles"
                    cmd.Connection = conn
                    cmd.Parameters.Clear()
                    cmd.Parameters.AddWithValue("@PartNum", FilePartNum)
                    cmd.Parameters.AddWithValue("@Rev", FileRev)
                    cmd.Parameters.AddWithValue("@check", 1)


                    If conn.State = ConnectionState.Closed Then
                        conn.Open()
                    End If

                    ds = cmd.ExecuteReader(CommandBehavior.CloseConnection)

                    Try
                        If ds.Read() Then
                            ''''PartNum & Rev Exist in BOM. No Archive
                        Else
                            ''''Archive
                            If CopyFile(fcheck, DestFile) Then
                                File.Delete(fcheck)
                            Else
                                ''''Keep track of files not copied/deleted?
                            End If
                        End If
                    Finally
                        ds.Close()
                    End Try

                ElseIf FileRevType = "mdl" Or FileRevType = "asm" Or FileRevType = "easm" Then

                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "getCleanUpFiles"
                    cmd.Connection = conn
                    cmd.Parameters.Clear()
                    cmd.Parameters.AddWithValue("@PartNum", FilePartNum)
                    cmd.Parameters.AddWithValue("@Rev", FileRev)
                    cmd.Parameters.AddWithValue("@check", 2)


                    If conn.State = ConnectionState.Closed Then
                        conn.Open()
                    End If

                    ds = cmd.ExecuteReader(CommandBehavior.CloseConnection)

                    Try
                        If ds.Read() Then
                            ''''PartNum & Rev Exist in BOM. No Archive
                        Else
                            ''''Archive
                            If CopyFile(fcheck, DestFile) Then
                                File.Delete(fcheck)
                            Else
                                ''''Keep track of files not copied/deleted?
                            End If
                        End If
                    Finally
                        ds.Close()
                    End Try


                End If

            Next

            Check = Nothing

        End If

    End Sub


    Private Function CopyFile(Source As String, Dest As String)
        Dim CopyCheck As Boolean
        CopyCheck = False

        Try
            FileSystem.FileCopy(Source, Dest)
            CopyCheck = True
        Catch ex As Exception
            CopyCheck = False
        End Try

        Return CopyCheck
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        drs = Directory.GetFiles(TextBox2.Text, "5478*")

        Dim FilePartNum As String
        Dim FileRev As String
        Dim FileRevType As String
        Dim FileType As String
        Dim DestFile As String
        Dim cmd As New SqlCommand


        For Each fcheck In drs

            FileRevType = mvs.Mid(fcheck, 45, 4)

            If FileRevType = "asm." Or FileRevType = "mdl." Or FileRevType = "dwg." Then
                FilePartNum = mvs.Mid(fcheck, 36, 9)
                FileRev = mvs.Mid(fcheck, 49, 5)
                FileType = mvs.Right(fcheck, 3)
            Else
                FileRevType = mvs.Mid(fcheck, 45, 5)
                FilePartNum = mvs.Mid(fcheck, 36, 9)
                FileRev = mvs.Mid(fcheck, 50, 5)
                FileType = mvs.Right(fcheck, 3)
            End If


            DestFile = "\\AUXSERVER1\ftp\Chieftain\" + FilePartNum + FileRevType + FileRev + FileType

            If CopyFile(fcheck, DestFile) Then
                File.Delete(fcheck)
            End If

        Next

    End Sub
End Class