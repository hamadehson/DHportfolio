﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PartRet_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PartRet_Form))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnFindFiles = New System.Windows.Forms.Button()
        Me.txtPN = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.txtDest = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtRev = New System.Windows.Forms.TextBox()
        Me.btnGetDest = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMdl = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.SelAssemblylistBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ChieftainDataSet2 = New Triad_NX75_Tools.chieftainDataSet2()
        Me.Sel_Assembly_listTableAdapter = New Triad_NX75_Tools.chieftainDataSet2TableAdapters.sel_Assembly_listTableAdapter()
        Me.ChieftainDataSet3 = New Triad_NX75_Tools.chieftainDataSet3()
        Me.SelAssemblylistPartRetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sel_Assembly_list_PartRetTableAdapter = New Triad_NX75_Tools.chieftainDataSet3TableAdapters.sel_Assembly_list_PartRetTableAdapter()
        Me.txtSourceBtn = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.SelAssemblylistBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChieftainDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChieftainDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SelAssemblylistPartRetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(198, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(223, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Part File Retrieval"
        '
        'BtnFindFiles
        '
        Me.BtnFindFiles.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFindFiles.Location = New System.Drawing.Point(241, 475)
        Me.BtnFindFiles.Name = "BtnFindFiles"
        Me.BtnFindFiles.Size = New System.Drawing.Size(133, 31)
        Me.BtnFindFiles.TabIndex = 5
        Me.BtnFindFiles.Text = "Find Files"
        Me.BtnFindFiles.UseVisualStyleBackColor = True
        '
        'txtPN
        '
        Me.txtPN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPN.Location = New System.Drawing.Point(172, 285)
        Me.txtPN.Name = "txtPN"
        Me.txtPN.Size = New System.Drawing.Size(172, 24)
        Me.txtPN.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(42, 287)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 20)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Part Number:"
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(218, 400)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(342, 24)
        Me.txtSearch.TabIndex = 10
        Me.txtSearch.TabStop = False
        '
        'txtDest
        '
        Me.txtDest.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDest.Location = New System.Drawing.Point(218, 430)
        Me.txtDest.Name = "txtDest"
        Me.txtDest.Size = New System.Drawing.Size(342, 24)
        Me.txtDest.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 400)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(119, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Source Folder:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(59, 427)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Destination:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(69, 319)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 20)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Dwg Rev:"
        '
        'txtRev
        '
        Me.txtRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRev.Location = New System.Drawing.Point(172, 315)
        Me.txtRev.Name = "txtRev"
        Me.txtRev.Size = New System.Drawing.Size(95, 24)
        Me.txtRev.TabIndex = 1
        '
        'btnGetDest
        '
        Me.btnGetDest.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetDest.Location = New System.Drawing.Point(172, 431)
        Me.btnGetDest.Name = "btnGetDest"
        Me.btnGetDest.Size = New System.Drawing.Size(40, 24)
        Me.btnGetDest.TabIndex = 3
        Me.btnGetDest.Text = "..."
        Me.btnGetDest.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextBox1.Location = New System.Drawing.Point(43, 63)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(517, 116)
        Me.TextBox1.TabIndex = 17
        Me.TextBox1.TabStop = False
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(76, 349)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 20)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Mdl Rev:"
        '
        'txtMdl
        '
        Me.txtMdl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMdl.Location = New System.Drawing.Point(172, 345)
        Me.txtMdl.Name = "txtMdl"
        Me.txtMdl.Size = New System.Drawing.Size(95, 24)
        Me.txtMdl.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(50, 207)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(510, 61)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "File Retrieval Mode"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(256, 21)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(119, 21)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Tree Retrieval"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(86, 21)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(152, 21)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Single Part Number"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'SelAssemblylistBindingSource
        '
        Me.SelAssemblylistBindingSource.DataMember = "sel_Assembly_list"
        Me.SelAssemblylistBindingSource.DataSource = Me.ChieftainDataSet2
        '
        'ChieftainDataSet2
        '
        Me.ChieftainDataSet2.DataSetName = "chieftainDataSet2"
        Me.ChieftainDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Sel_Assembly_listTableAdapter
        '
        Me.Sel_Assembly_listTableAdapter.ClearBeforeFill = True
        '
        'ChieftainDataSet3
        '
        Me.ChieftainDataSet3.DataSetName = "chieftainDataSet3"
        Me.ChieftainDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SelAssemblylistPartRetBindingSource
        '
        Me.SelAssemblylistPartRetBindingSource.DataMember = "sel_Assembly_list_PartRet"
        Me.SelAssemblylistPartRetBindingSource.DataSource = Me.ChieftainDataSet3
        '
        'Sel_Assembly_list_PartRetTableAdapter
        '
        Me.Sel_Assembly_list_PartRetTableAdapter.ClearBeforeFill = True
        '
        'txtSourceBtn
        '
        Me.txtSourceBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSourceBtn.Location = New System.Drawing.Point(172, 401)
        Me.txtSourceBtn.Name = "txtSourceBtn"
        Me.txtSourceBtn.Size = New System.Drawing.Size(40, 24)
        Me.txtSourceBtn.TabIndex = 22
        Me.txtSourceBtn.Text = "..."
        Me.txtSourceBtn.UseVisualStyleBackColor = True
        '
        'PartRet_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 541)
        Me.Controls.Add(Me.txtSourceBtn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtMdl)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnGetDest)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtRev)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtDest)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtPN)
        Me.Controls.Add(Me.BtnFindFiles)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PartRet_Form"
        Me.Text = "Part File Retrieval"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.SelAssemblylistBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChieftainDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChieftainDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SelAssemblylistPartRetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents BtnFindFiles As Button
    Friend WithEvents txtPN As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtDest As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtRev As TextBox
    Friend WithEvents btnGetDest As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtMdl As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents SelAssemblylistBindingSource As BindingSource
    Friend WithEvents ChieftainDataSet2 As chieftainDataSet2
    Friend WithEvents Sel_Assembly_listTableAdapter As chieftainDataSet2TableAdapters.sel_Assembly_listTableAdapter
    Friend WithEvents ChieftainDataSet3 As chieftainDataSet3
    Friend WithEvents SelAssemblylistPartRetBindingSource As BindingSource
    Friend WithEvents Sel_Assembly_list_PartRetTableAdapter As chieftainDataSet3TableAdapters.sel_Assembly_list_PartRetTableAdapter
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents txtSourceBtn As Button
End Class
