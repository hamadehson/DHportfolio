﻿Imports System.IO
Imports mvs = Microsoft.VisualBasic.Strings
Imports Microsoft.Office.Interop.Excel
Imports System.Data.SqlClient


Public Class BomReportUseQty

    Dim SpecRep As Boolean
    Dim VehList As String = ""
    Dim SpecificReport As String = ""
    Dim lvl2only As String = ""
    Dim IncPO As String = ""
    Dim IncIA As String = ""
    Dim ExcPIA As String = ""
    Dim ExcTMF As String = ""
    Dim FormatType As String = ""
    Dim BOMType As String = ""
    Dim DemandCalcType As String = ""
    Dim StationTabs As String = ""
    Dim InventoryGroups As String = ""
    Dim JobNums As String = ""
    Dim SelectStatus As String = ""
    Dim SpecNotes As String = ""
    Dim ComponentType As String = ""
    Public Dbstring As String = ""
    Public UserId As String = ""
    Public Password As String = ""
    Public JobChoice As Integer




    Dim cmd As SqlCommand
    Dim ds As SqlDataReader
    Public conn As SqlConnection


    Public Sub BomReportUseQty_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ChkExcTMF.Checked = True
        ChkExcPIA.Checked = True
        ChkIncPO.Checked = True
        ChkIncIA.Checked = True

        RadioButton31.Checked = True
        RadioButton29.Checked = True
        RadioButton26.Checked = True
        RadioButton25.Checked = True
        RadioButton10.Checked = True
        RadioButton15.Checked = True
        RadioButton3.Checked = True
        RadioButton18.Checked = True
        SpecRep = False

        Dbstring = FDBLogin.Dbstring
        UserId = FDBLogin.UserString
        Password = FDBLogin.PassString
        conn = New SqlConnection("Server=databasesvr3;DataBase=" & Dbstring & ";User Id=" & UserId & ";Password=" & Password & "")
        conn.Open()

        GetVehicles()
        GetInvGroups()
        GetJobNums()

        ListBox1.Visible = False
        ListBox2.Visible = False
        CheckedListBox1.Visible = False
        ProgressBar1.Visible = False
        Barlbl.Visible = False

        TabControl1.TabPages.Remove(TabPage2)
        TabControl1.TabPages.Remove(TabPage3)
        TabControl1.TabPages.Remove(TabPage4)


    End Sub

    Private Sub btnP1Next_Click(sender As Object, e As EventArgs) Handles btnP1Next.Click

        If TabControl1.TabPages.Contains(TabPage2) Then
            TabControl1.SelectedTab = TabPage2
        Else
            TabControl1.TabPages.Add(TabPage2)
            TabControl1.SelectedTab = TabPage2
        End If

    End Sub

    Private Sub btnP1Cancel_Click(sender As Object, e As EventArgs) Handles btnP1Cancel.Click
        Close()
    End Sub

    Private Sub btnP2Next_Click(sender As Object, e As EventArgs) Handles btnP2Next.Click

        For Each Item In LBVeh.Items

            If VehList = "" Then
                VehList = LBVeh.GetItemText(Item)
            Else
                VehList = VehList + ", " + LBVeh.GetItemText(Item)
            End If

        Next

        If SpecRep = False Then
            SpecificReport = "No Specific IA or Assembly"
        ElseIf SpecRep = True And RadioButton13.Checked = False And RadioButton12.Checked = False Then
            MessageBox.Show("Please select a Report Type.")
            gbReportType.Select()
            Exit Sub
        Else
            If RadioButton13.Checked = True Then
                SpecificReport = "Specific Assembly: "
            End If
            If RadioButton12.Checked = True Then
                SpecificReport = "Specific IA: "
            End If
        End If

        If SpecRep = True And (RadioButton13.Checked = True Or RadioButton12.Checked = True) And cmbAssemIA.SelectedValue = "Select One" Then
            MessageBox.Show("Please select an Assembly or IA to report.")
            cmbAssemIA.Select()
            Exit Sub
        End If

        If ChkLvl2.Checked = True Then
            lvl2only = "Yes"
        Else
            lvl2only = "No"
        End If

        If ChkIncPO.Checked = True Then
            IncPO = "Yes"
        Else
            IncPO = "No"
        End If

        If ChkIncIA.Checked = True Then
            IncIA = "Yes"
        Else
            IncIA = "No"
        End If

        If ChkExcPIA.Checked = True Then
            ExcPIA = "Yes"
        Else
            ExcPIA = "No"
        End If

        If ChkExcTMF.Checked = True Then
            ExcTMF = "Yes"
        Else
            ExcTMF = "No"
        End If

        If ChkSpecNote.Checked = True Then
            SpecNotes = "Yes"
        Else
            SpecNotes = "No"
        End If


        If TabControl1.TabPages.Contains(TabPage3) Then
            TabControl1.SelectedTab = TabPage3
        Else
            TabControl1.TabPages.Add(TabPage3)
            TabControl1.SelectedTab = TabPage3
        End If

    End Sub

    Private Sub btnP2Back_Click(sender As Object, e As EventArgs) Handles btnP2Back.Click
        TabControl1.SelectedTab = TabPage1
    End Sub

    Private Sub btnP2Cancel_Click(sender As Object, e As EventArgs) Handles btnP2Cancel.Click
        Close()
    End Sub

    Private Sub btnP3Next_Click(sender As Object, e As EventArgs) Handles btnP3Next.Click

        Dim SM As Integer = 0

        '''' Format type
        If RadioButton31.Checked = False And RadioButton30.Checked = False Then
            MessageBox.Show("Please select a format type.")
            GroupBox12.Select()
            Exit Sub
        ElseIf RadioButton31.Checked = True Then
            FormatType = "IA-Full"
        Else
            FormatType = "IA-Manufacturing"
        End If

        '''' Bom type
        If RadioButton29.Checked = False And RadioButton28.Checked = False Then
            MessageBox.Show("Please select a BOM type.")
            GroupBox11.Select()
            Exit Sub
        ElseIf RadioButton29.Checked = True Then
            BOMType = "Indented BOM"
        Else
            BOMType = "Build Readiness BOM"
        End If

        '''' Demand Calculation type
        If RadioButton26.Checked = False And RadioButton27.Checked = False Then
            MessageBox.Show("Please select a demand calculation type.")
            GroupBox10.Select()
            Exit Sub
        ElseIf RadioButton27.Checked = True Then
            DemandCalcType = "Include PO's"
        Else
            DemandCalcType = "Ignore PO's"
        End If

        '''' Station Tabs
        If RadioButton25.Checked = False And RadioButton24.Checked = False And RadioButton23.Checked = False Then
            MessageBox.Show("Please select an option for station tabs.")
            GroupBox9.Select()
            Exit Sub
        ElseIf RadioButton25.Checked = True Then
            StationTabs = "None"
        ElseIf RadioButton24.Checked = True Then
            StationTabs = "Flat List"
        Else
            StationTabs = "Indented List"
        End If

        '''' Inventory Groups
        If RadioButton10.Checked = False And RadioButton11.Checked = False And RadioButton14.Checked = False Then
            MessageBox.Show("Please select an option for inventory groups.")
            GroupBox5.Select()
            Exit Sub
        ElseIf RadioButton11.Checked = True And ListBox1.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select at least 1 inventory group from the list or change your selection type.")
            ListBox1.Select()
            Exit Sub
        End If

        If RadioButton1.Checked = False And RadioButton2.Checked = False And RadioButton3.Checked = False Then
            MessageBox.Show("Please select an option for Component Types.")
            GroupBox1.Select()
        ElseIf RadioButton1.Checked = True Then
            ComponentType = "Components Only"
        ElseIf RadioButton2.Checked = True Then
            ComponentType = "Make-from Components Only"
        Else
            ComponentType = "All (Final & Make-from Components)"
        End If

        '''' PO/PR/SWO Status
        If RadioButton18.Checked = False And RadioButton22.Checked = False And RadioButton4.Checked = False Then
            MessageBox.Show("Please select an option for PR/PO/SWO Status.")
            GroupBox8.Select()
            Exit Sub
        ElseIf RadioButton18.Checked = True Then
            SelectStatus = "All"
        ElseIf RadioButton4.Checked = True Then
            SelectStatus = "List Selection"
        Else
            SelectStatus = "None"
        End If

        '''' Insert filterlist options
        Clear_tFilterList(0)

        Insert_tFilterList(10, 4)
        Insert_tFilterList(12, 1)
        Insert_tFilterList(16, 0)
        Insert_tFilterList(21, 0)
        Insert_tFilterList(22, 0)
        Insert_tFilterList(31, 2)

        '''' Alternate Parent Bomid Options
        Insert_tFilterList(11, 0)
        Insert_tFilterList(35, 0)

        If ChkLvl2.Checked = True Then
            Insert_tFilterList(17, 1)
        Else
            Insert_tFilterList(17, 0)
        End If

        If ChkIncPO.Checked = True Then
            Insert_tFilterList(32, 1)
        Else
            Insert_tFilterList(32, 0)
        End If

        If ChkIncIA.Checked = True Then
            Insert_tFilterList(20, 1)
        Else
            Insert_tFilterList(20, 0)
        End If

        If ChkExcPIA.Checked = True Then
            Insert_tFilterList(18, 1)
        Else
            Insert_tFilterList(18, 0)
        End If

        If ChkExcTMF.Checked = True Then
            Insert_tFilterList(28, 1)
        Else
            Insert_tFilterList(28, 0)
        End If

        If RadioButton1.Checked = True Then
            Insert_tFilterList(13, 0)
            Insert_tFilterList(14, 1)
        ElseIf RadioButton2.Checked = True Then
            Insert_tFilterList(13, 1)
            Insert_tFilterList(14, 0)
        Else
            Insert_tFilterList(13, 0)
            Insert_tFilterList(14, 0)
        End If

        If RadioButton30.Checked = True Then
            Insert_tFilterList(27, 1)
        Else
            Insert_tFilterList(27, 0)
        End If

        If RadioButton18.Checked = True Then
            Insert_tFilterList(30, 0)
        ElseIf RadioButton4.Checked = True Then
            Insert_tFilterList(30, 1)
        Else
            Insert_tFilterList(30, 2)
        End If

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        cmd = New SqlCommand
        cmd.CommandText = "delete from PRSWO_Status_Select where userid = '" & UserId & "'"
        cmd.Connection = conn
        cmd.ExecuteNonQuery()

        If CheckedListBox1.GetItemChecked(0) = True Then
            cmd = New SqlCommand
            cmd.CommandText = "insert into PRSWO_Status_Select select 1,'o', '" & UserId & "'"
            cmd.Connection = conn
            cmd.ExecuteNonQuery()
        End If

        If CheckedListBox1.GetItemChecked(1) = True Then
            cmd = New SqlCommand
            cmd.CommandText = "insert into PRSWO_Status_Select select 2,'c', '" & UserId & "'"
            cmd.Connection = conn
            cmd.ExecuteNonQuery()
        End If

        If CheckedListBox1.GetItemChecked(2) = True Then
            cmd = New SqlCommand
            cmd.CommandText = "insert into PRSWO_Status_Select select 3,'x', '" & UserId & "'"
            cmd.Connection = conn
            cmd.ExecuteNonQuery()
        End If

        If RadioButton11.Checked = True Then

            For Each rowView As DataRowView In ListBox1.SelectedItems

                If InventoryGroups = "" Then
                    InventoryGroups = ListBox1.GetItemText(rowView)
                Else
                    InventoryGroups = InventoryGroups + ", " + ListBox1.GetItemText(rowView)
                End If

                SM = CInt(rowView("inventorygroupid"))
                Insert_tFilterList(33, SM)
            Next

        ElseIf RadioButton10.Checked Then
            InventoryGroups = "All"
            cmd = New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "put_invgroup_in_filterlist"
            cmd.Connection = conn

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd.ExecuteNonQuery()
        Else
            InventoryGroups = "None"
            Clear_tFilterList(33)
        End If


        '''' Job Numbers
        If RadioButton15.Checked = False And RadioButton16.Checked = False And RadioButton17.Checked = False Then
            MessageBox.Show("Please select an option for PR/PO/SWO Job Numbers.")
            GroupBox7.Select()
            Exit Sub
        ElseIf RadioButton17.Checked = True And ListBox2.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select at least 1 job number from the list or change your selection type.")
            ListBox2.Select()
            Exit Sub
        End If

        If RadioButton11.Checked = False Then

            If RadioButton17.Checked = True Then

                For Each rowView As DataRowView In ListBox2.SelectedItems

                    If JobNums = "" Then
                        JobNums = ListBox2.GetItemText(rowView)
                    Else
                        JobNums = JobNums + ", " + ListBox2.GetItemText(rowView)
                    End If

                    SM = CInt(rowView("JobNumber"))
                    Insert_tFilterList(23, SM)
                Next

            ElseIf RadioButton16.Checked Then
                JobNums = "All"
                Clear_tFilterList(23)
            Else
                JobNums = "Active Only"
                cmd = New SqlCommand
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "put_jobnum_in_filterlist"
                cmd.Connection = conn

                If conn.State = ConnectionState.Closed Then
                    conn.Open()
                End If

                cmd.ExecuteNonQuery()

            End If
        Else
            JobNums = "None"
            Clear_tFilterList(23)
        End If

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "UpdateTempVehicleList"
        cmd.Connection = conn
        cmd.Parameters.Clear()

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()

        If TabControl1.TabPages.Contains(TabPage4) Then
            TabControl1.SelectedTab = TabPage4
        Else
            TabControl1.TabPages.Add(TabPage4)
            TabControl1.SelectedTab = TabPage4
        End If

        RichTextBox1.Text = "Current Report Overview:" & vbCrLf & vbCrLf &
            "Selected Vehicle Quantities: " & VehList & vbCrLf &
            "Specific Assembly/IA Report: " & SpecificReport & vbCrLf &
            "Level 2 Parts Only: " & lvl2only & vbCrLf &
            "Include POs: " & IncPO & vbCrLf &
            "Include IAs: " & IncIA & vbCrLf &
            "Exclude PIA Items: " & ExcPIA & vbCrLf &
            "Exclude Non-Triad Make Froms: " & ExcTMF & vbCrLf &
            "Include Special Notes: " & SpecNotes & vbCrLf &
            "Format Type: " & FormatType & vbCrLf &
            "BOM Type: " & BOMType & vbCrLf &
            "Demand Calculation Type: " & DemandCalcType & vbCrLf &
            "Station Tabs: " & StationTabs & vbCrLf &
            "Inventory Groups: " & InventoryGroups & vbCrLf &
            "Job Numbers: " & JobNums & vbCrLf &
            "PR/PO/SWO Status: " & SelectStatus & vbCrLf &
            "Component Types: " & ComponentType

    End Sub

    Private Sub btnP3Back_Click(sender As Object, e As EventArgs) Handles btnP3Back.Click
        TabControl1.SelectedTab = TabPage2
    End Sub

    Private Sub btnP3Cancel_Click(sender As Object, e As EventArgs) Handles btnP3Cancel.Click
        Close()
    End Sub

    Private Sub btnP4Back_Click(sender As Object, e As EventArgs) Handles btnP4Back.Click
        TabControl1.SelectedTab = TabPage3
    End Sub

    Private Sub btnP4Cancel_Click(sender As Object, e As EventArgs) Handles btnP4Cancel.Click
        Close()
    End Sub


    Private Sub btnSpecAssem_Click(sender As Object, e As EventArgs) Handles btnSpecAssem.Click

        If gbReportType.Visible = False Then
            gbReportType.Visible = True
            SpecRep = True
        Else
            RadioButton12.Checked = False
            RadioButton13.Checked = False
            gbReportType.Visible = False
            cmbAssemIA.Visible = False
            Label7.Visible = False
            SpecRep = False
        End If

    End Sub

    Private Sub gbReportType_Enter(sender As Object, e As EventArgs) Handles gbReportType.Enter

        cmbAssemIA.Visible = True
        Label7.Visible = True

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "sel_Assembly_list"
        cmd.Connection = conn
        cmd.Parameters.Clear()

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        ds = cmd.ExecuteReader()


    End Sub

    Public Sub Clear_tFilterList(FilterTypeId As Integer)

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Clear_tfilterlist"
        cmd.Connection = conn
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@Filtertypeid", FilterTypeId)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()

    End Sub

    Public Sub Insert_tFilterList(FilterTypeId As Integer, FilterId As String)

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Insert_tfilterlist"
        cmd.Connection = conn
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@Filtertypeid", FilterTypeId)
        cmd.Parameters.AddWithValue("@Filterid", FilterId)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()

    End Sub

    Private Sub RadioButton11_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton11.CheckedChanged
        If RadioButton11.Checked = True Then
            ListBox1.Visible = True
        Else
            ListBox1.Visible = False
        End If

        If RadioButton17.Checked = True Then
            ListBox2.Visible = True
        End If
        GroupBox7.Visible = True
        RadioButton15.Visible = True
        RadioButton16.Visible = True
        RadioButton17.Visible = True

    End Sub

    Private Sub RadioButton17_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton17.CheckedChanged
        If RadioButton17.Checked = True Then
            ListBox2.Visible = True
        Else
            ListBox2.Visible = False
        End If
    End Sub

    Public Sub GetJobNums()

        If RadioButton15.Checked = True Then
            JobChoice = 0
        ElseIf RadioButton16.Checked = True Then
            JobChoice = 1
        Else RadioButton17.Checked = True
            JobChoice = 2
        End If


        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "FilterList_Jobnum_invgroup"
        cmd.Connection = conn
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@invgroup", JobChoice)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Dim da = New SqlDataAdapter(cmd)
        Dim dt = New System.Data.DataTable("JobNumbers")
        da.Fill(dt)
        ListBox2.DataSource = dt
        ListBox2.DisplayMember = "Description"
        ListBox2.ValueMember = "Jobnumber"

    End Sub

    Public Sub GetInvGroups()

        Dim SelStmt1 As String
        SelStmt1 = "Select Inventorygroupname, inventorygroupid from Inventorygroup Order by inventorygroupid"
        Dim cmdlb1 As New SqlCommand(SelStmt1, conn)
        Dim DAlb1 As New SqlDataAdapter(cmdlb1)
        Dim DTlb1 As New System.Data.DataTable("InventoryGroups")
        DAlb1.Fill(DTlb1)

        ListBox1.DataSource = DTlb1
        ListBox1.DisplayMember = "inventorygroupname"
        ListBox1.ValueMember = "inventorygroupid"

    End Sub

    Public Sub GetVehicles()

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "getTempVehicleList_2"
        cmd.Connection = conn

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Dim da = New SqlDataAdapter(cmd)
        Dim dt = New System.Data.DataTable("Vehicles")
        da.Fill(dt)

        CmbVeh.DataSource = dt
        CmbVeh.DisplayMember = "VehicleName"
        CmbVeh.ValueMember = "VehicleId"

    End Sub

    Private Sub BtnAddVeh_Click(sender As Object, e As EventArgs) Handles BtnAddVeh.Click

        Dim KeyCheck As Boolean = True

        If TxtQty.Text = "" Then
            MessageBox.Show("Please enter a vehicle quantity.")
            TxtQty.Select()
            KeyCheck = False
            Exit Sub
        End If

        If KeyCheck = True Then
            LBVeh.Items.Add("ID: " + CmbVeh.SelectedValue.ToString() + "   " + CmbVeh.Text + " - Qty:  " + TxtQty.Text)

            cmd = New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "Update_TempVehicleList"
            cmd.Connection = conn
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@VehicleId", CInt(CmbVeh.SelectedValue))
            cmd.Parameters.AddWithValue("@VehicleName", CmbVeh.Text)
            cmd.Parameters.AddWithValue("@VehicleQty", CInt(TxtQty.Text))
            cmd.Parameters.AddWithValue("@Check", 0)

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd.ExecuteNonQuery()
        End If

    End Sub

    Private Sub BtnRemVeh_Click(sender As Object, e As EventArgs) Handles BtnRemVeh.Click

        If LBVeh.SelectedItems.Count = 0 Then

            MessageBox.Show("Please select the vehicle to be removed.")
            LBVeh.Select()

        Else

            Dim VehId As String = Mid(LBVeh.SelectedItem, 5, 3)

            cmd = New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "Update_TempVehicleList"
            cmd.Connection = conn
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@VehicleId", CInt(VehId))
            cmd.Parameters.AddWithValue("@VehicleName", CmbVeh.Text)
            cmd.Parameters.AddWithValue("@VehicleQty", CInt(TxtQty.Text))
            cmd.Parameters.AddWithValue("@Check", 2)

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd.ExecuteNonQuery()

            LBVeh.Items.Remove(LBVeh.SelectedItem)

        End If

    End Sub

    Private Sub BtnDelVeh_Click(sender As Object, e As EventArgs) Handles BtnDelVeh.Click

        LBVeh.Items.Clear()

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Update_TempVehicleList"
        cmd.Connection = conn
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@VehicleId", 0)
        cmd.Parameters.AddWithValue("@VehicleName", "")
        cmd.Parameters.AddWithValue("@VehicleQty", 0)
        cmd.Parameters.AddWithValue("@Check", 1)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()

    End Sub

    Private Sub RadioButton14_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton14.CheckedChanged

        ListBox2.Visible = False
        GroupBox7.Visible = False
        RadioButton15.Visible = False
        RadioButton16.Visible = False
        RadioButton17.Visible = False

    End Sub

    Private Sub RadioButton10_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton10.CheckedChanged

        If RadioButton17.Checked = True Then
            ListBox2.Visible = True
        End If
        GroupBox7.Visible = True
        RadioButton15.Visible = True
        RadioButton16.Visible = True
        RadioButton17.Visible = True

    End Sub

    Private Sub RadioButton18_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton18.CheckedChanged
        CheckedListBox1.Visible = False
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        CheckedListBox1.Visible = True
    End Sub

    Private Sub RadioButton22_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton22.CheckedChanged
        CheckedListBox1.Visible = False
    End Sub

    Private Sub RadioButton29_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton29.CheckedChanged
        ChkIncIA.Checked = True
    End Sub

    Private Sub RadioButton28_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton28.CheckedChanged
        ChkIncIA.Checked = False
    End Sub

    Private Sub btnFinal_Click(sender As Object, e As EventArgs) Handles btnFinal.Click

        Dim fname As String = ""
        Dim fpath As String = String.Empty
        Dim BOMtype As Integer = 0
        Dim Formattype As Integer = 0
        Dim fdate As String = Today.Month & "-" & Today.Day & "-" & Today.Year
        Dim saveFileDialog1 = New SaveFileDialog()
        Dim mystream As Stream
        Dim I As Integer = 0


        ProgressBar1.Visible = True
        ProgressBar1.Value = 0
        Barlbl.Visible = True

        '''' Get File Save Information --------------------------------------------------------
        If RadioButton29.Checked = True Then
            fname = "Indented BOM"
        Else
            fname = "Build Readiness BOM"
        End If

        If RadioButton31.Checked = True Then
            fname = "Use Qty IA-Full " & fname
        Else
            fname = "Use Qty IA-Manufacturing " & fname
        End If
        fname = fDate & " " & fname

        ProgressBar1.Value = ProgressBar1.Value + 5 ''5
        Barlbl.Text = "Setting Filename & Path"

        saveFileDialog1.Title = "Save Report"
        saveFileDialog1.Filter = "Excel File (*.xlsx)|*.xlsx"
        saveFileDialog1.FileName = fname
        saveFileDialog1.OverwritePrompt = True
        saveFileDialog1.RestoreDirectory = True

        If saveFileDialog1.ShowDialog() = DialogResult.OK Then
            fpath = saveFileDialog1.FileName
            mystream = saveFileDialog1.OpenFile()
            mystream.Close()
        Else
            ProgressBar1.Visible = True
            ProgressBar1.Value = 0
            Barlbl.Visible = True
            Exit Sub
        End If

        ProgressBar1.Value = ProgressBar1.Value + 5 ''10
        Barlbl.Text = "Building Report: Stored Procedure #1"
        Refresh()

        '''' Run Stored Procedures to populate BOM info --------------------------------------------------------
        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "New_prod_BOM_Step1_R18"
        cmd.Connection = conn
        cmd.CommandTimeout = 720

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()


        ProgressBar1.Value = ProgressBar1.Value + 15 ''25
        Barlbl.Text = "Building Report: Stored Procedure #2"
        Refresh()

        While I > 100
            I = I + 1
        End While

        cmd = New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "New_prod_BOM_EXPOut_9"
        cmd.Connection = conn
        cmd.CommandTimeout = 720

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        cmd.ExecuteNonQuery()


        '''' Build the Excel Sheet --------------------------------------------------------
        Dim xlApp As Application
        Dim xlWb As Workbook
        Dim xlWs As Worksheet
        Dim TemplatePath As String = String.Empty
        Dim TemplateComtext As String = String.Empty
        Dim LineLocComText As String = String.Empty
        Dim SQLstring As String = String.Empty
        Dim SQLstring2 As String = String.Empty
        Dim SQLstring3 As String = String.Empty
        Dim RS As New ADODB.Recordset
        Dim RS2 As New ADODB.Recordset
        Dim RS3 As New ADODB.Recordset
        Dim myConnection As ADODB.Connection = New ADODB.Connection
        Dim myConnection2 As ADODB.Connection = New ADODB.Connection
        Dim LocName As String = String.Empty
        Dim rCount As Integer = 0

        ProgressBar1.Value = ProgressBar1.Value + 30 ''''55
        Barlbl.Text = "Build Report: Begin Populating Workbook"
        Me.Refresh()

        If (RadioButton30.Checked = True And ChkSpecNote.Checked = False) Then
            TemplatePath = "\\databasesvr3\support\excel output templates\MFG_Demand_Exp_Output_1.xltx"
            TemplateComtext = "get_MFG_exp_output"
            LineLocComText = "get_MFG_reportLineLocData"
        ElseIf (RadioButton30.Checked = True And ChkSpecNote.Checked = True) Then
            TemplatePath = "\\databasesvr3\support\excel output templates\MFG_Demand_Exp_Output_Special.xltx"
            TemplateComtext = "get_MFG_exp_output"
            LineLocComText = "get_MFG_reportLineLocData"
        ElseIf (RadioButton31.Checked = True And ChkSpecNote.Checked = False) Then
            TemplatePath = "\\databasesvr3\support\excel output templates\Demand_Exp_Output_5.xltx"
            TemplateComtext = "get_full_exp_output"
            LineLocComText = "get_reportLineLocData"
        Else
            TemplatePath = "\\databasesvr3\support\excel output templates\Demand_Exp_Output_Special.xltx"
            TemplateComtext = "get_full_exp_output"
            LineLocComText = "get_reportLineLocData"
        End If


        xlApp = CreateObject("Excel.Application")
        xlApp.DisplayAlerts = False
        xlWb = xlApp.Workbooks.Add(TemplatePath)



        ProgressBar1.Value = ProgressBar1.Value + 10 ''''65
        Barlbl.Text = "Populating Full BOM Worksheet"
        Me.Refresh()

        xlWs = xlWb.Worksheets(1)
        xlWs.Name = "Full BOM"


        If ChkSpecNote.Checked = True And RadioButton31.Checked = True Then
            SQLstring3 = "Exec get_full_exp_output_Special"
        ElseIf ChkSpecNote.Checked = False And RadioButton31.Checked = True Then
            SQLstring3 = "Exec get_full_exp_output"
        ElseIf ChkSpecNote.Checked = True And RadioButton31.Checked = False Then
            SQLstring3 = "Exec get_MFG_exp_output_Special"
        Else
            SQLstring3 = "Exec get_MFG_exp_output"
        End If

        myConnection.ConnectionString = "Driver={ODBC Driver 13 for SQL Server};Server=databasesvr3;DataBase=" & Dbstring & ";User Id=" & UserId & ";Password=" & Password & ""
        myConnection.Open()

        RS3.Open(SQLstring3, myConnection)

        If Not (RS3.EOF Or RS3.BOF) Then
            xlWs.Cells(2, 1).CopyFromRecordset(RS3)
        Else
            RS3.MoveFirst()
            Me.Refresh()
            xlWs.Cells(2, 1).CopyFromRecordset(RS3)
        End If

        RS3.Close()


        ProgressBar1.Value = ProgressBar1.Value + 5 ''''70
        Barlbl.Text = "Initial Workbook Save"
        Me.Refresh()

        If Val(xlApp.Version) < 12 Then
            xlWb.SaveAs2(fpath, Len(fpath) - InStr(fpath, "."))
        Else
            xlWb.SaveAs2(fpath)
        End If

        If RadioButton25.Checked = False Then

            ProgressBar1.Value = ProgressBar1.Value + 10 ''''80
            Barlbl.Text = "Filling Worksheets/Tabs"
            Me.Refresh()


            SQLstring = "Exec get_reportLineLocList"
            myConnection2.ConnectionString = "Driver={ODBC Driver 13 for SQL Server};Server=databasesvr3;DataBase=" & Dbstring & ";User Id=" & UserId & ";Password=" & Password & ""
            myConnection2.Open()

            RS.Open(SQLstring, myConnection)

            If Not (RS.EOF Or RS.BOF) Then
                RS.MoveFirst()
                Me.Refresh()

                While (Not RS.EOF)

                    If IsNothing(RS.Fields("loc")) Then
                        LocName = "Null"
                    Else
                        LocName = RS.Fields("loc").Value.ToString()
                    End If

                    xlWs = xlWb.Sheets.Add(After:=xlWb.Sheets(xlWb.Sheets.Count), Type:=TemplatePath)


                    SQLstring2 = "Exec get_reportLineLocData " & "'" & LocName & "'"
                    RS2.Open(SQLstring2, myConnection2)

                    rCount = RS2.RecordCount

                    If Not RS2.EOF Then
                        xlWs.Cells(2, 1).CopyFromRecordset(RS2)
                    End If
                    RS2.Close()

                    If LocName = "" Then
                        LocName = "None"
                    End If

                    xlWs.Name = LocName

                    RS.MoveNext()
                End While

            End If

        End If

        xlWs = xlWb.Sheets.Add(After:=xlWb.Sheets(xlWb.Sheets.Count), Type:="\\databasesvr3\support\excel output templates\Demand_Exp_Output_6.xltx")

        ProgressBar1.Value = 99 ''''100
        Barlbl.Text = "Format Worksheets"
        Me.Refresh()


        For I = 1 To xlWb.Sheets.Count

            xlWs = xlWb.Worksheets(I)

            xlWs.Rows("1:1").RowHeight = 125

            xlWb.ActiveSheet.PageSetup.RightHeader = "Data Creation  Date: " & CDate(Now)
            xlWb.ActiveSheet.PageSetup.CenterHeader = "Use Qty Based Indented Bill of Material"

        Next I

        xlWs = xlWb.Worksheets("Data Criteria")
        xlWs.Range("a2").Value = RichTextBox1.Text



        xlWb.SaveAs2(fpath)
        xlWb.Close()
        xlApp.DisplayAlerts = True
        xlWs = Nothing
        xlWb = Nothing
        xlApp.Quit()
        xlApp = Nothing


        ProgressBar1.Value = 100 ''100
        ProgressBar1.Visible = False
        Barlbl.Visible = False

    End Sub


End Class